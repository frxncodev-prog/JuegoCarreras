// ============ utils.js — utilidades matemáticas ============
const U = {
  clamp(v,a,b){ return v<a?a:(v>b?b:v); },
  lerp(a,b,t){ return a+(b-a)*t; },
  dist(x1,y1,x2,y2){ const dx=x2-x1, dy=y2-y1; return Math.hypot(dx,dy); },
  rand(a,b){ return a+Math.random()*(b-a); },
  randi(a,b){ return Math.floor(U.rand(a,b+1)); },
  pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; },
  // diferencia angular en [-PI, PI]
  angDiff(a,b){ let d=b-a; while(d>Math.PI)d-=2*Math.PI; while(d<-Math.PI)d+=2*Math.PI; return d; },
  // formato de tiempo mm:ss.mmm
  fmtTime(ms){
    if(ms==null||!isFinite(ms)) return '--:--.---';
    const m=Math.floor(ms/60000), s=Math.floor((ms%60000)/1000), mm=Math.floor(ms%1000);
    return m+':'+String(s).padStart(2,'0')+'.'+String(mm).padStart(3,'0');
  },
  fmtMoney(n){ return n.toLocaleString('es-ES'); },
  // punto a polar
  P(deg,r){ const t=deg*Math.PI/180; return [Math.cos(t)*r, Math.sin(t)*r]; }
};
