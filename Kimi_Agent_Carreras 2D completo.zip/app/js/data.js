// ============ data.js — contenido del juego ============
// Todas las marcas, vehículos y circuitos son ficticios.

const CATS = {
  kart:    { name:'Karting',    color:'#ffd34d', desc:'Ágiles, ligeros y directos' },
  touring: { name:'Turismos',   color:'#7fd0ff', desc:'Equilibrio y resistencia' },
  gt3:     { name:'GT3',        color:'#9dff70', desc:'Agarre de competición' },
  super:   { name:'Supercars',  color:'#ff9d5c', desc:'Potencia extrema' },
  f2:      { name:'Fórmula 2',  color:'#c39dff', desc:'Monoplazas afilados' },
  f1:      { name:'Fórmula 1',  color:'#ff5c7a', desc:'La cima de la velocidad' },
};
const CAT_ORDER = ['kart','touring','gt3','super','f2','f1'];

// stats: top (m/s), acc (m/s²), brk (m/s²), grip (amortiguación lateral /s), drift (retención lateral 0-1)
// price en CR, lvl = nivel de XP requerido
const VEHICLES = [
  // ---- Karting ----
  { id:'kart1', cat:'kart', name:'Sprite 100',   price:0,     lvl:1,  colors:['#ffd34d','#222831'], stats:{top:36, acc:9.5, brk:14, grip:10.5, drift:0.55} },
  { id:'kart2', cat:'kart', name:'Rocket K1',    price:2800,  lvl:1,  colors:['#ff5c5c','#ffffff'], stats:{top:38, acc:10.2, brk:14.5, grip:11, drift:0.5} },
  { id:'kart3', cat:'kart', name:'Blitz Mini',   price:4500,  lvl:2,  colors:['#7fd0ff','#0b0e17'], stats:{top:40, acc:11, brk:15, grip:11.5, drift:0.45} },
  // ---- Turismos ----
  { id:'tou1', cat:'touring', name:'Falcón RS',  price:9000,  lvl:2,  colors:['#3a7bd5','#dfe9f3'], stats:{top:52, acc:10.5, brk:15, grip:8.8, drift:0.35} },
  { id:'tou2', cat:'touring', name:'Torino GR',  price:12500, lvl:3,  colors:['#d53a3a','#1a1a1a'], stats:{top:55, acc:11, brk:15.5, grip:9.2, drift:0.32} },
  { id:'tou3', cat:'touring', name:'Vortex ST',  price:16000, lvl:3,  colors:['#2eb872','#f5f5f5'], stats:{top:57, acc:11.8, brk:16, grip:9.6, drift:0.3} },
  // ---- GT3 ----
  { id:'gt31', cat:'gt3', name:'Aquila GT',      price:24000, lvl:4,  colors:['#9dff70','#103020'], stats:{top:61, acc:12.5, brk:19, grip:12, drift:0.28} },
  { id:'gt32', cat:'gt3', name:'Veneno R3',      price:31000, lvl:5,  colors:['#8a2be2','#e0e0ff'], stats:{top:64, acc:13.2, brk:20, grip:12.6, drift:0.26} },
  { id:'gt33', cat:'gt3', name:'Corsa 520',      price:39000, lvl:6,  colors:['#ff8c00','#202020'], stats:{top:66, acc:14, brk:21, grip:13.2, drift:0.24} },
  // ---- Supercars ----
  { id:'sup1', cat:'super', name:'Hyperion S',   price:48000, lvl:6,  colors:['#ff9d5c','#2b1608'], stats:{top:71, acc:14.5, brk:20, grip:11.4, drift:0.3} },
  { id:'sup2', cat:'super', name:'Falcata X',    price:64000, lvl:8,  colors:['#00d2d3','#062b2b'], stats:{top:75, acc:15.5, brk:21, grip:12, drift:0.28} },
  { id:'sup3', cat:'super', name:'Orion Z',      price:82000, lvl:9,  colors:['#f0f0f0','#c20000'], stats:{top:78, acc:16.5, brk:22, grip:12.6, drift:0.26} },
  // ---- Fórmula 2 ----
  { id:'f21', cat:'f2', name:'Apex F2-A',        price:95000,  lvl:8,  colors:['#c39dff','#221133'], stats:{top:76, acc:17, brk:26, grip:15, drift:0.2} },
  { id:'f22', cat:'f2', name:'Stinger 22',       price:118000, lvl:10, colors:['#ffe066','#333300'], stats:{top:79, acc:18, brk:27, grip:15.8, drift:0.19} },
  { id:'f23', cat:'f2', name:'Vortex FR',        price:142000, lvl:11, colors:['#66ffe0','#003333'], stats:{top:82, acc:19, brk:28, grip:16.5, drift:0.18} },
  // ---- Fórmula 1 ----
  { id:'f11', cat:'f1', name:'Pegasus X1',       price:190000, lvl:11, colors:['#ff5c7a','#330a12'], stats:{top:87, acc:20, brk:30, grip:18, drift:0.16} },
  { id:'f12', cat:'f1', name:'Thunder FR1',      price:250000, lvl:13, colors:['#5c8aff','#0a1233'], stats:{top:90, acc:21.5, brk:31, grip:18.8, drift:0.15} },
  { id:'f13', cat:'f1', name:'Comet C44',        price:320000, lvl:14, colors:['#e8e8e8','#ff3700'], stats:{top:93, acc:23, brk:32, grip:19.6, drift:0.14} },
];

// Circuitos: puntos de control en orden angular (antihorario), ancho en metros
const TRACKS = [
  { id:'t1', name:'Costa Azul', width:16, laps:3, theme:'coast',
    pts:[U.P(0,520),U.P(28,565),U.P(58,540),U.P(90,600),U.P(122,560),U.P(152,520),U.P(180,565),U.P(210,620),U.P(242,560),U.P(272,505),U.P(302,525),U.P(332,545)] },
  { id:'t2', name:'Valle Verde', width:15, laps:3, theme:'forest',
    pts:[U.P(0,470),U.P(24,425),U.P(50,475),U.P(76,525),U.P(102,465),U.P(128,425),U.P(158,505),U.P(188,565),U.P(218,515),U.P(248,465),U.P(282,545),U.P(312,495),U.P(338,460)] },
  { id:'t3', name:'Desierto Rojo', width:18, laps:3, theme:'desert',
    pts:[U.P(0,640),U.P(30,700),U.P(62,660),U.P(95,720),U.P(128,640),U.P(160,610),U.P(195,690),U.P(228,720),U.P(262,650),U.P(296,615),U.P(330,660)] },
  { id:'t4', name:'Puerto Nocturno', width:14, laps:4, theme:'street',
    pts:[U.P(0,420),U.P(24,360),U.P(52,430),U.P(80,350),U.P(108,440),U.P(136,370),U.P(164,450),U.P(192,380),U.P(220,460),U.P(250,370),U.P(280,440),U.P(308,360),U.P(334,430)] },
  { id:'t5', name:'Montaña Nevada', width:14, laps:3, theme:'snow',
    pts:[U.P(0,480),U.P(26,390),U.P(54,470),U.P(86,380),U.P(116,500),U.P(148,420),U.P(178,520),U.P(210,400),U.P(242,510),U.P(274,430),U.P(306,500),U.P(334,420)] },
  { id:'t6', name:'Selva Tropical', width:15, laps:3, theme:'jungle',
    pts:[U.P(0,500),U.P(30,440),U.P(58,520),U.P(88,460),U.P(120,540),U.P(150,470),U.P(182,530),U.P(212,450),U.P(244,520),U.P(276,460),U.P(308,530),U.P(336,470)] },
  { id:'t7', name:'Lago Serena', width:17, laps:3, theme:'lake',
    pts:[U.P(0,600),U.P(34,560),U.P(66,640),U.P(100,590),U.P(134,660),U.P(168,600),U.P(202,650),U.P(236,580),U.P(270,640),U.P(304,590),U.P(332,630)] },
  { id:'t8', name:'Autódromo Estrella', width:16, laps:3, theme:'gp',
    pts:[U.P(0,540),U.P(22,480),U.P(44,560),U.P(66,470),U.P(92,580),U.P(118,520),U.P(144,590),U.P(170,500),U.P(196,570),U.P(224,490),U.P(252,580),U.P(280,510),U.P(308,560),U.P(334,500)] },
];

// Temas visuales de circuito
const THEMES = {
  coast:  { grass:'#3d8a3f', grass2:'#357a37', road:'#4a4d55', deco:'tree',  decoColor:'#1e5c20' },
  forest: { grass:'#2f7a33', grass2:'#286b2c', road:'#45484f', deco:'tree',  decoColor:'#144d18' },
  desert: { grass:'#c8a15a', grass2:'#b8924e', road:'#55555c', deco:'rock',  decoColor:'#8a6a3a' },
  street: { grass:'#3a3f4a', grass2:'#333845', road:'#3f424c', deco:'lamp',  decoColor:'#ffd34d' },
  snow:   { grass:'#dfe8f0', grass2:'#cfdae6', road:'#4d5058', deco:'pine',  decoColor:'#2a5a3a' },
  jungle: { grass:'#1f6b2a', grass2:'#1a5d24', road:'#484b52', deco:'tree',  decoColor:'#0d3d12' },
  lake:   { grass:'#3f8a50', grass2:'#377a46', road:'#4a4d55', deco:'lake',  decoColor:'#2a6a9a' },
  gp:     { grass:'#4a8a3f', grass2:'#427a38', road:'#50535a', deco:'stand', decoColor:'#8a2be2' },
};

// Campeonato
const CHAMP_POINTS = [10,8,6,5,4,3,2,1];
const RACE_PRIZES  = [3000,2400,2000,1700,1500,1300,1100,1000]; // por posición final
const RACE_XP      = [500,380,320,280,250,220,200,180];
const CHAMP_BONUS  = 15000;
const DIFFS = {
  easy:   { name:'Fácil',   aiSkill:0.82, prizeMult:0.8, xpMult:0.8 },
  normal: { name:'Normal',  aiSkill:0.92, prizeMult:1.2, xpMult:1.1 },
  hard:   { name:'Difícil', aiSkill:1.0,  prizeMult:1.6, xpMult:1.5 },
};

// Mejoras: 4 niveles cada una
const UPGRADES = {
  engine: { name:'Motor',        icon:'🔥', max:4, cost:l=>1500*(l+1), apply:s=>{ s.acc*=1.07; s.top*=1.03; } },
  brakes: { name:'Frenos',       icon:'🛑', max:4, cost:l=>1200*(l+1), apply:s=>{ s.brk*=1.08; } },
  tires:  { name:'Neumáticos',   icon:'⭕', max:4, cost:l=>1300*(l+1), apply:s=>{ s.grip*=1.06; } },
  aero:   { name:'Aerodinámica', icon:'🌬', max:4, cost:l=>1400*(l+1), apply:s=>{ s.top*=1.025; s.grip*=1.03; } },
};
const UPG_KEYS = ['engine','brakes','tires','aero'];

const AI_NAMES = ['Vega','Ríos','Kova','Lombardi','Tanaka','Moreau','Santos','Ibrahim','Costa','Novak','Ferrero','Lindqvist'];

const CONDITIONS = [
  { id:'day',       name:'☀ Día',          night:false, rain:false },
  { id:'night',     name:'🌙 Noche',       night:true,  rain:false },
  { id:'rain_day',  name:'🌧 Lluvia día',  night:false, rain:true },
  { id:'rain_night',name:'⛈ Lluvia noche', night:true,  rain:true },
];

// nivel de XP: cada nivel requiere 800*xp acumulados aprox.
function xpToLevel(xp){ return Math.min(15, Math.floor(xp/800)+1); }
