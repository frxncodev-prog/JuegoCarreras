// ============================================================
// Pantallas de menú: inicio, configuración de carrera, garage,
// campeonato, resultados, ayuda
// ============================================================
import { useState } from 'react';
import {
  CATEGORIES, VEHICLES, TRACKS, UPGRADES, UPGRADE_MAX, CHAMPIONSHIPS, POINTS,
  DIFFICULTIES, WEATHERS, vehiclesByCategory, vehicleById, trackById, upgradeCost,
  levelFromXp, xpProgress, XP_PER_LEVEL,
  type Category, type Vehicle, type TrackDef, type DifficultyId, type WeatherOption,
} from '../game/data';
import { fmtMoney, fmtTime, upOf, type SaveData } from '../game/save';
import type { RaceManager, RaceMode } from '../game/race';
import type { RaceConfig } from '../game/race';

export type Screen =
  | { name: 'home' }
  | { name: 'setup'; mode: RaceMode }
  | { name: 'garage' }
  | { name: 'champ' }
  | { name: 'race'; cfg: RaceConfig }
  | { name: 'results'; race: RaceManager; rewards: { money: number; xp: number }; champSummary?: string }
  | { name: 'help' };

export interface Ctx {
  save: SaveData;
  setSave: (s: SaveData) => void;
  go: (s: Screen) => void;
}

// ---------- componentes base ----------
export function Header({ ctx, title, back }: { ctx: Ctx; title: string; back?: Screen }) {
  const lvl = levelFromXp(ctx.save.xp);
  return (
    <div className="flex items-center justify-between gap-3 mb-5 flex-wrap">
      <div className="flex items-center gap-3">
        {back && (
          <button onClick={() => ctx.go(back)} className="w-11 h-11 rounded-xl bg-white/10 border border-white/15 text-xl font-black active:bg-white/20">←</button>
        )}
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-wide uppercase">{title}</h1>
      </div>
      <div className="flex items-center gap-3">
        <div className="card-dark px-3 py-1.5 text-center">
          <div className="text-[10px] text-white/50 tracking-widest">NIVEL {lvl}</div>
          <div className="stat-bar w-24 mt-1"><div style={{ width: `${xpProgress(ctx.save.xp) * 100}%` }} /></div>
        </div>
        <div className="card-dark px-4 py-2 font-bold text-[#d2ff00] text-lg">{fmtMoney(ctx.save.money)}</div>
      </div>
    </div>
  );
}

function StatRow({ label, value, max }: { label: string; value: number; max: number }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-24 text-xs text-white/60 uppercase tracking-wider">{label}</span>
      <div className="stat-bar flex-1"><div style={{ width: `${Math.min(100, (value / max) * 100)}%` }} /></div>
      <span className="w-10 text-right text-xs text-white/70">{Math.round(value)}</span>
    </div>
  );
}

export function effStats(v: Vehicle, up: { engine: number; brakes: number; tires: number; aero: number }) {
  const s = v.stats;
  return {
    topSpeed: s.topSpeed * (1 + up.engine * 0.025),
    accel: s.accel * (1 + up.engine * 0.05),
    grip: s.grip * (1 + up.tires * 0.045) * (1 + up.aero * 0.04),
    brake: s.brake * (1 + up.brakes * 0.07),
  };
}

export function VehicleCard({ v, owned, up, selected, locked, onClick }: {
  v: Vehicle; owned: boolean; up?: { engine: number; brakes: number; tires: number; aero: number };
  selected?: boolean; locked?: boolean; onClick?: () => void;
}) {
  const st = effStats(v, up ?? { engine: 0, brakes: 0, tires: 0, aero: 0 });
  const cat = CATEGORIES.find(c => c.id === v.category)!;
  return (
    <button onClick={onClick}
      className={`card-dark p-4 text-left w-full transition-all active:scale-[0.98] ${selected ? 'ring-2 ring-[#d2ff00]' : ''} ${locked ? 'opacity-50' : ''}`}>
      <div className="flex justify-between items-start gap-2">
        <div>
          <div className="font-display font-bold text-lg leading-tight">{v.name}</div>
          <div className="text-xs uppercase tracking-widest" style={{ color: cat.color }}>{cat.name}</div>
        </div>
        <div className="w-10 h-10 rounded-lg shrink-0" style={{ background: `linear-gradient(135deg, ${v.colors[0]} 55%, ${v.colors[1]} 55%)` }} />
      </div>
      <div className="mt-3 space-y-1.5">
        <StatRow label="V. Máx" value={st.topSpeed} max={380} />
        <StatRow label="Acel." value={st.accel * 10} max={220} />
        <StatRow label="Agarre" value={st.grip * 50} max={140} />
        <StatRow label="Frenos" value={st.brake * 3} max={110} />
      </div>
      <div className="mt-3 text-sm font-bold">
        {owned ? <span className="text-[#d2ff00]">EN GARAGE</span> :
          locked ? <span className="text-[#ff624d]">NIVEL {v.unlockLevel} REQUERIDO</span> :
          <span className="text-[#ffd23e]">{fmtMoney(v.price)}</span>}
      </div>
    </button>
  );
}

// ---------- INICIO ----------
export function HomeScreen({ ctx }: { ctx: Ctx }) {
  const lvl = levelFromXp(ctx.save.xp);
  return (
    <div className="screen bg-grid flex flex-col max-w-5xl mx-auto">
      <div className="flex-1 flex flex-col items-center justify-center text-center py-8">
        <div className="text-[#d2ff00] tracking-[0.5em] text-sm font-bold mb-2">CARRERAS ARCADE 2D</div>
        <h1 className="font-display text-6xl md:text-8xl font-black italic leading-none">
          APEX<span className="text-[#3834ff]">RUSH</span>
        </h1>
        <div className="text-white/50 mt-2 tracking-widest">6 CATEGORÍAS · 8 CIRCUITOS · 24 VEHÍCULOS</div>

        <div className="grid grid-cols-2 md:grid-cols-2 gap-3 mt-10 w-full max-w-md">
          <button className="menu-btn bg-[#3834ff] text-white" onClick={() => ctx.go({ name: 'setup', mode: 'quick' })}>🏁 Carrera rápida</button>
          <button className="menu-btn bg-[#d2ff00] text-black" onClick={() => ctx.go({ name: 'champ' })}>🏆 Campeonato</button>
          <button className="menu-btn bg-white/10 text-white" onClick={() => ctx.go({ name: 'setup', mode: 'timetrial' })}>⏱ Contrarreloj</button>
          <button className="menu-btn bg-white/10 text-white" onClick={() => ctx.go({ name: 'garage' })}>🔧 Garage</button>
        </div>
        <button className="mt-3 text-white/40 text-sm underline underline-offset-4" onClick={() => ctx.go({ name: 'help' })}>Cómo jugar / Controles</button>
      </div>

      <div className="card-dark p-4 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#3834ff] flex items-center justify-center font-display font-black text-xl">{lvl}</div>
          <div>
            <div className="text-xs text-white/50 tracking-widest">PILOTO — NIVEL {lvl}</div>
            <div className="stat-bar w-40 md:w-64 mt-1"><div style={{ width: `${xpProgress(ctx.save.xp) * 100}%` }} /></div>
            <div className="text-[10px] text-white/40 mt-1">{ctx.save.xp % XP_PER_LEVEL}/{XP_PER_LEVEL} XP · {ctx.save.wins} victorias / {ctx.save.racesDone} carreras</div>
          </div>
        </div>
        <div className="font-bold text-[#d2ff00] text-2xl">{fmtMoney(ctx.save.money)}</div>
      </div>
    </div>
  );
}

// ---------- CONFIGURACIÓN DE CARRERA (rápida / contrarreloj) ----------
export function SetupScreen({ ctx, mode }: { ctx: Ctx; mode: RaceMode }) {
  const lvl = levelFromXp(ctx.save.xp);
  const [cat, setCat] = useState<Category>(CATEGORIES[0]);
  const ownedInCat = vehiclesByCategory(cat.id).filter(v => ctx.save.owned.includes(v.id));
  const [vehId, setVehId] = useState<string>('');
  const [trackId, setTrackId] = useState<string>('');
  const [laps, setLaps] = useState(0);
  const [weather, setWeather] = useState<WeatherOption>(WEATHERS[0]);
  const [diff, setDiff] = useState<DifficultyId>('medium');

  const selVeh = ownedInCat.find(v => v.id === vehId) ?? ownedInCat[0];
  const selTrack = TRACKS.find(t => t.id === trackId) ?? TRACKS[0];
  const bestKey = `${selTrack.id}:${cat.id}`;
  const best = ctx.save.bestTimes[bestKey];

  const canStart = !!selVeh;
  const start = () => {
    if (!selVeh) return;
    ctx.go({
      name: 'race',
      cfg: {
        trackId: selTrack.id, category: cat.id, vehicleId: selVeh.id,
        laps: laps || selTrack.laps, difficulty: diff, weather, mode,
        aiCount: mode === 'timetrial' ? 0 : 7, save: ctx.save,
      },
    });
  };

  return (
    <div className="screen bg-grid max-w-6xl mx-auto">
      <Header ctx={ctx} title={mode === 'timetrial' ? 'Contrarreloj' : 'Carrera rápida'} back={{ name: 'home' }} />
      <div className="grid md:grid-cols-2 gap-5 pb-8">
        <div className="space-y-5">
          <section>
            <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">CATEGORÍA</h3>
            <div className="grid grid-cols-3 gap-2">
              {CATEGORIES.map(c => (
                <button key={c.id} onClick={() => { setCat(c); setVehId(''); }}
                  className={`card-dark p-3 text-center active:scale-95 transition-all ${cat.id === c.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>
                  <div className="font-display font-black text-xl" style={{ color: c.color }}>{c.icon}</div>
                  <div className="text-[11px] font-bold mt-1">{c.name}</div>
                </button>
              ))}
            </div>
          </section>
          <section>
            <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">VEHÍCULO</h3>
            <div className="grid grid-cols-2 gap-2 max-h-[340px] overflow-y-auto pr-1">
              {vehiclesByCategory(cat.id).map(v => {
                const owned = ctx.save.owned.includes(v.id);
                const locked = lvl < v.unlockLevel;
                return <VehicleCard key={v.id} v={v} owned={owned} locked={!owned && locked}
                  up={upOf(ctx.save, v.id)}
                  selected={selVeh?.id === v.id}
                  onClick={() => { if (owned) setVehId(v.id); }} />;
              })}
            </div>
            <div className="text-xs text-white/40 mt-2">Compra más vehículos en el Garage.</div>
          </section>
        </div>
        <div className="space-y-5">
          <section>
            <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">CIRCUITO</h3>
            <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto pr-1">
              {TRACKS.map((t: TrackDef) => (
                <button key={t.id} onClick={() => setTrackId(t.id)}
                  className={`card-dark p-3 text-left active:scale-95 transition-all ${selTrack.id === t.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>
                  <div className="font-bold">{t.name}</div>
                  <div className="text-[11px] text-white/50">{t.country} · {t.desc}</div>
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3 mt-3">
              <span className="text-xs text-white/50 tracking-widest">VUELTAS</span>
              {[1, 2, 3, 4, 5, 6].map(n => (
                <button key={n} onClick={() => setLaps(n)}
                  className={`w-10 h-10 rounded-lg font-bold ${((laps || selTrack.laps) === n) ? 'bg-[#3834ff] text-white' : 'bg-white/10 text-white/60'}`}>{n}</button>
              ))}
            </div>
            {best ? <div className="text-xs text-[#d2ff00] mt-2">Récord personal: {fmtTime(best)}</div> : null}
          </section>
          <section>
            <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">CLIMA</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {WEATHERS.map(w => (
                <button key={w.id} onClick={() => setWeather(w)}
                  className={`card-dark p-3 text-left active:scale-95 ${weather.id === w.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>
                  <div className="font-bold text-sm">{w.name}</div>
                  <div className="text-[11px] text-white/50">{w.desc}</div>
                </button>
              ))}
            </div>
          </section>
          {mode !== 'timetrial' && (
            <section>
              <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">DIFICULTAD</h3>
              <div className="grid grid-cols-3 gap-2">
                {DIFFICULTIES.map(d => (
                  <button key={d.id} onClick={() => setDiff(d.id)}
                    className={`card-dark p-3 text-center active:scale-95 ${diff === d.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>
                    <div className="font-bold">{d.name}</div>
                    <div className="text-[11px] text-white/50">{d.desc}</div>
                  </button>
                ))}
              </div>
            </section>
          )}
          <button disabled={!canStart} onClick={start}
            className="menu-btn bg-[#d2ff00] text-black w-full text-2xl disabled:opacity-40">
            {mode === 'timetrial' ? '⏱ INICIAR CONTRARRELOJ' : '🏁 A LA PARRILLA'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- GARAGE ----------
export function GarageScreen({ ctx }: { ctx: Ctx }) {
  const lvl = levelFromXp(ctx.save.xp);
  const [tab, setTab] = useState<'owned' | 'shop'>('owned');
  const [selId, setSelId] = useState(ctx.save.owned[0] ?? VEHICLES[0].id);
  const sel = vehicleById(selId);
  const owned = ctx.save.owned.includes(selId);
  const locked = lvl < sel.unlockLevel;
  const up = upOf(ctx.save, selId);

  const list = tab === 'owned'
    ? VEHICLES.filter(v => ctx.save.owned.includes(v.id))
    : VEHICLES.filter(v => !ctx.save.owned.includes(v.id));

  const buy = () => {
    if (ctx.save.money < sel.price || locked) return;
    const s = { ...ctx.save, money: ctx.save.money - sel.price, owned: [...ctx.save.owned, sel.id] };
    ctx.setSave(s); setTab('owned');
  };
  const buyUp = (id: 'engine' | 'brakes' | 'tires' | 'aero') => {
    const cur = up[id];
    if (cur >= UPGRADE_MAX) return;
    const cost = upgradeCost(sel.price || 4000, cur);
    if (ctx.save.money < cost) return;
    const s = { ...ctx.save, money: ctx.save.money - cost, upgrades: { ...ctx.save.upgrades, [selId]: { ...up, [id]: cur + 1 } } };
    ctx.setSave(s);
  };
  const st = effStats(sel, up);

  return (
    <div className="screen bg-grid max-w-6xl mx-auto pb-8">
      <Header ctx={ctx} title="Garage" back={{ name: 'home' }} />
      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab('owned')} className={`menu-btn flex-1 ${tab === 'owned' ? 'bg-[#3834ff] text-white' : 'bg-white/10 text-white/60'}`}>Mis vehículos ({ctx.save.owned.length})</button>
        <button onClick={() => setTab('shop')} className={`menu-btn flex-1 ${tab === 'shop' ? 'bg-[#3834ff] text-white' : 'bg-white/10 text-white/60'}`}>Concesionario</button>
      </div>
      <div className="grid md:grid-cols-2 gap-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto pr-1 content-start">
          {list.map(v => (
            <VehicleCard key={v.id} v={v} owned={ctx.save.owned.includes(v.id)} locked={lvl < v.unlockLevel}
              up={upOf(ctx.save, v.id)} selected={selId === v.id} onClick={() => setSelId(v.id)} />
          ))}
          {list.length === 0 && <div className="text-white/40 col-span-2 py-10 text-center">No hay vehículos aquí todavía.</div>}
        </div>
        <div className="card-dark p-5">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="font-display text-2xl font-bold">{sel.name}</h2>
              <div className="text-white/50 text-sm">{sel.desc}</div>
            </div>
            <div className="w-14 h-14 rounded-xl shrink-0" style={{ background: `linear-gradient(135deg, ${sel.colors[0]} 55%, ${sel.colors[1]} 55%)` }} />
          </div>
          <div className="mt-4 space-y-2">
            <StatRow label="V. Máx" value={st.topSpeed} max={380} />
            <StatRow label="Acel." value={st.accel * 10} max={220} />
            <StatRow label="Agarre" value={st.grip * 50} max={140} />
            <StatRow label="Frenos" value={st.brake * 3} max={110} />
          </div>

          {owned ? (
            <div className="mt-5">
              <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">MEJORAS</h3>
              <div className="space-y-2">
                {UPGRADES.map(u => {
                  const cur = up[u.id as keyof typeof up];
                  const cost = upgradeCost(sel.price || 4000, cur);
                  const maxed = cur >= UPGRADE_MAX;
                  return (
                    <div key={u.id} className="flex items-center gap-3 bg-white/5 rounded-xl p-3">
                      <span className="text-xl">{u.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm">{u.name}</div>
                        <div className="flex gap-1 mt-1">
                          {Array.from({ length: UPGRADE_MAX }).map((_, i) => (
                            <div key={i} className={`h-2 flex-1 rounded ${i < cur ? 'bg-[#d2ff00]' : 'bg-white/10'}`} />
                          ))}
                        </div>
                      </div>
                      <button disabled={maxed || ctx.save.money < cost} onClick={() => buyUp(u.id as any)}
                        className="menu-btn bg-[#3834ff] text-white text-sm px-4 py-2 disabled:opacity-30">
                        {maxed ? 'MAX' : fmtMoney(cost)}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="mt-5">
              {locked ? (
                <div className="text-[#ff624d] font-bold">🔒 Requiere nivel de piloto {sel.unlockLevel} (eres nivel {lvl})</div>
              ) : (
                <button onClick={buy} disabled={ctx.save.money < sel.price}
                  className="menu-btn bg-[#d2ff00] text-black w-full text-xl disabled:opacity-40">
                  COMPRAR — {fmtMoney(sel.price)}
                </button>
              )}
              {ctx.save.money < sel.price && !locked && <div className="text-white/40 text-sm mt-2">Te faltan {fmtMoney(sel.price - ctx.save.money)}.</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- CAMPEONATO ----------
export function ChampScreen({ ctx }: { ctx: Ctx }) {

  const active = ctx.save.champ;
  const [selChamp, setSelChamp] = useState(CHAMPIONSHIPS[0].id);
  const [selVeh, setSelVeh] = useState('');
  const [diff, setDiff] = useState<DifficultyId>('medium');
  const chDef = CHAMPIONSHIPS.find(c => c.id === (active?.champId ?? selChamp))!;

  const ownedInCat = vehiclesByCategory(chDef.category).filter(v => ctx.save.owned.includes(v.id));
  const veh = ownedInCat.find(v => v.id === selVeh) ?? ownedInCat[0];

  const startChamp = () => {
    if (!veh) return;
    const standings = [{ name: 'TÚ', points: 0, isPlayer: true }];
    for (let i = 0; i < 7; i++) standings.push({ name: ['Vidal','Kessler','Onofre','Sato','Marchetti','Ivanov','Duarte'][i], points: 0, isPlayer: false });
    const s = { ...ctx.save, champ: { champId: chDef.id, vehicleId: veh.id, raceIdx: 0, standings } };
    ctx.setSave(s);
  };

  const abandon = () => { ctx.setSave({ ...ctx.save, champ: null }); };

  const nextRace = () => {
    if (!active) return;
    const trackId = chDef.tracks[active.raceIdx];
    const grid = [...active.standings].sort((a, b) => b.points - a.points).map(s => s.name);
    const weather = WEATHERS[(active.raceIdx * 2 + chDef.id.length) % WEATHERS.length];
    ctx.go({
      name: 'race',
      cfg: {
        trackId, category: chDef.category, vehicleId: active.vehicleId,
        laps: trackById(trackId).laps, difficulty: diff, weather,
        mode: 'championship', aiCount: 7, save: ctx.save, champGrid: grid,
      },
    });
  };

  if (active) {
    const sorted = [...active.standings].sort((a, b) => b.points - a.points);
    const done = active.raceIdx >= chDef.tracks.length;
    const playerRank = sorted.findIndex(s => s.isPlayer) + 1;
    return (
      <div className="screen bg-grid max-w-3xl mx-auto pb-8">
        <Header ctx={ctx} title={chDef.name} back={{ name: 'home' }} />
        <div className="card-dark p-4 mb-4 flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="text-xs text-white/50 tracking-widest">PROGRESO</div>
            <div className="font-display text-2xl font-bold">Carrera {Math.min(active.raceIdx + 1, chDef.tracks.length)}/{chDef.tracks.length}</div>
            <div className="text-sm text-white/60">{vehicleById(active.vehicleId).name} · {CATEGORIES.find(c => c.id === chDef.category)?.name}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-white/50 tracking-widest">TU POSICIÓN</div>
            <div className="font-display text-4xl font-black text-[#d2ff00]">P{playerRank}</div>
          </div>
        </div>

        {done ? (
          <div className="card-dark p-6 text-center mb-4">
            <div className="text-5xl mb-2">{playerRank === 1 ? '🏆' : playerRank <= 3 ? '🏅' : '🏁'}</div>
            <h2 className="font-display text-3xl font-black">{playerRank === 1 ? '¡CAMPEÓN!' : `CAMPEONATO TERMINADO — P${playerRank}`}</h2>
            <p className="text-white/60 mt-1">Premio: {fmtMoney(Math.round(chDef.prize * (playerRank === 1 ? 1 : playerRank === 2 ? 0.5 : playerRank === 3 ? 0.3 : 0.1)))}</p>
            <button className="menu-btn bg-[#3834ff] text-white mt-4 w-full" onClick={() => {
              const prize = Math.round(chDef.prize * (playerRank === 1 ? 1 : playerRank === 2 ? 0.5 : playerRank === 3 ? 0.3 : 0.1));
              const won = playerRank === 1;
              ctx.setSave({
                ...ctx.save, money: ctx.save.money + prize, champ: null,
                champsWon: won ? [...ctx.save.champsWon, chDef.id] : ctx.save.champsWon,
              });
            }}>RECOGER PREMIO</button>
          </div>
        ) : (
          <div className="card-dark p-4 mb-4">
            <div className="text-xs text-white/50 tracking-widest mb-1">PRÓXIMA CARRERA</div>
            <div className="font-bold text-xl">{trackById(chDef.tracks[active.raceIdx]).name}</div>
            <div className="text-sm text-white/50">{trackById(chDef.tracks[active.raceIdx]).desc}</div>
            <div className="grid grid-cols-3 gap-2 mt-3">
              {DIFFICULTIES.map(d => (
                <button key={d.id} onClick={() => setDiff(d.id)}
                  className={`card-dark p-2 text-center text-sm font-bold ${diff === d.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>{d.name}</button>
              ))}
            </div>
            <button className="menu-btn bg-[#d2ff00] text-black w-full mt-3 text-xl" onClick={nextRace}>🏁 DISPUTAR CARRERA</button>
          </div>
        )}

        <div className="card-dark p-4">
          <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">CLASIFICACIÓN</h3>
          {sorted.map((s, i) => (
            <div key={s.name} className={`flex items-center gap-3 py-2 px-2 rounded-lg ${s.isPlayer ? 'bg-[#3834ff]/25' : ''}`}>
              <span className={`w-8 font-display font-black ${i === 0 ? 'text-[#ffd23e]' : i < 3 ? 'text-white/80' : 'text-white/40'}`}>{i + 1}</span>
              <span className="flex-1 font-bold">{s.name}{s.isPlayer ? ' (Tú)' : ''}</span>
              <span className="font-display font-bold text-[#d2ff00]">{s.points} pts</span>
            </div>
          ))}
        </div>
        <button className="mt-4 text-[#ff624d]/80 text-sm underline underline-offset-4" onClick={abandon}>Abandonar campeonato</button>
      </div>
    );
  }

  // selector de nuevo campeonato
  return (
    <div className="screen bg-grid max-w-6xl mx-auto pb-8">
      <Header ctx={ctx} title="Campeonato" back={{ name: 'home' }} />
      <div className="grid md:grid-cols-2 gap-5">
        <div className="space-y-2">
          {CHAMPIONSHIPS.map(c => {
            const cat = CATEGORIES.find(x => x.id === c.category)!;
            const won = ctx.save.champsWon.includes(c.id);
            return (
              <button key={c.id} onClick={() => { setSelChamp(c.id); setSelVeh(''); }}
                className={`card-dark p-4 w-full text-left active:scale-[0.98] transition-all ${selChamp === c.id ? 'ring-2 ring-[#d2ff00]' : ''}`}>
                <div className="flex justify-between items-center">
                  <div className="font-display font-bold text-lg">{c.name} {won && '🏆'}</div>
                  <span className="text-xs font-bold px-2 py-1 rounded" style={{ background: cat.color + '33', color: cat.color }}>{cat.name}</span>
                </div>
                <div className="text-sm text-white/50 mt-1">{c.tracks.length} carreras · Premio {fmtMoney(c.prize)}</div>
                <div className="text-[11px] text-white/40 mt-1">{c.tracks.map(t => trackById(t).name).join(' · ')}</div>
              </button>
            );
          })}
        </div>
        <div>
          <h3 className="text-xs tracking-[0.3em] text-white/50 mb-2">TU VEHÍCULO — {CATEGORIES.find(c => c.id === chDef.category)?.name.toUpperCase()}</h3>
          {ownedInCat.length === 0 ? (
            <div className="card-dark p-6 text-center text-white/50">
              No tienes vehículos de esta categoría.<br />
              <button className="menu-btn bg-[#3834ff] text-white mt-4" onClick={() => ctx.go({ name: 'garage' })}>IR AL GARAGE</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ownedInCat.map(v => (
                <VehicleCard key={v.id} v={v} owned up={upOf(ctx.save, v.id)} selected={(veh?.id ?? '') === v.id} onClick={() => setSelVeh(v.id)} />
              ))}
            </div>
          )}
          <button disabled={!veh} onClick={startChamp} className="menu-btn bg-[#d2ff00] text-black w-full mt-4 text-xl disabled:opacity-40">
            🏆 INICIAR {chDef.name.toUpperCase()}
          </button>
          <div className="text-xs text-white/40 mt-2">Puntos por carrera: {POINTS.slice(0, 8).join(' · ')}. La parrilla se ordena por puntos.</div>
        </div>
      </div>
    </div>
  );
}

// ---------- RESULTADOS ----------
export function ResultsScreen({ ctx, race, rewards, champSummary }: {
  ctx: Ctx; race: RaceManager; rewards: { money: number; xp: number }; champSummary?: string;
}) {
  const entries = race.finalEntries;
  const playerWon = race.playerPos === 1;
  return (
    <div className="screen bg-grid max-w-2xl mx-auto flex flex-col">
      <div className="text-center py-6">
        <div className="text-6xl mb-2">{playerWon ? '🏆' : race.playerPos <= 3 ? '🏅' : '🏁'}</div>
        <h1 className="font-display text-4xl md:text-5xl font-black italic">
          {race.cfg.mode === 'timetrial' ? 'SESIÓN TERMINADA' : playerWon ? '¡VICTORIA!' : `P${race.playerPos} — META`}
        </h1>
        <div className="text-white/50 mt-1">{trackById(race.cfg.trackId).name} · {CATEGORIES.find(c => c.id === race.cfg.category)?.name} · {race.cfg.weather.name}</div>
      </div>

      <div className="card-dark p-4 mb-4">
        {entries.map((e, i) => (
          <div key={e.name} className={`flex items-center gap-3 py-2 px-2 rounded-lg ${e.isPlayer ? 'bg-[#3834ff]/25' : ''}`}>
            <span className={`w-8 font-display font-black ${i === 0 ? 'text-[#ffd23e]' : 'text-white/50'}`}>{i + 1}</span>
            <div className="flex-1 min-w-0">
              <div className="font-bold truncate">{e.name}{e.isPlayer ? ' (Tú)' : ''}</div>
              <div className="text-[11px] text-white/40">{e.vehName}</div>
            </div>
            <div className="text-right">
              <div className="font-display font-bold">{e.time > 0 ? fmtTime(e.time) : 'DNF'}</div>
              <div className="text-[11px] text-[#d2ff00]">{fmtTime(e.bestLap)}</div>
            </div>
            {race.cfg.mode === 'championship' && <div className="w-10 text-right text-white/60 text-sm">+{POINTS[i] ?? 0}</div>}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="card-dark p-4 text-center">
          <div className="text-xs text-white/50 tracking-widest">DINERO</div>
          <div className="font-display text-2xl font-black text-[#d2ff00]">+{fmtMoney(rewards.money)}</div>
        </div>
        <div className="card-dark p-4 text-center">
          <div className="text-xs text-white/50 tracking-widest">EXPERIENCIA</div>
          <div className="font-display text-2xl font-black text-[#3834ff]" style={{ color: '#8a86ff' }}>+{rewards.xp} XP</div>
        </div>
      </div>
      {champSummary && <div className="card-dark p-3 mb-4 text-center text-sm text-white/70">{champSummary}</div>}

      <div className="grid grid-cols-2 gap-3 pb-8 mt-auto">
        <button className="menu-btn bg-white/10 text-white" onClick={() => {
          const cfg = { ...race.cfg, save: ctx.save };
          ctx.go({ name: 'race', cfg });
        }}>↻ Repetir</button>
        <button className="menu-btn bg-[#d2ff00] text-black" onClick={() => {
          ctx.go(race.cfg.mode === 'championship' ? { name: 'champ' } : { name: 'home' });
        }}>Continuar →</button>
      </div>
    </div>
  );
}

// ---------- AYUDA ----------
export function HelpScreen({ ctx }: { ctx: Ctx }) {
  return (
    <div className="screen bg-grid max-w-2xl mx-auto pb-10">
      <Header ctx={ctx} title="Cómo jugar" back={{ name: 'home' }} />
      <div className="space-y-4 text-white/70">
        <div className="card-dark p-4">
          <h3 className="font-display font-bold text-white mb-2">🖥 CONTROLES PC</h3>
          <p><b className="text-white">WASD o Flechas</b> — acelerar, frenar y girar.<br />
          <b className="text-white">Espacio</b> — freno de mano (derrape).<br />
          <b className="text-white">Esc / P</b> — pausa.<br />
          <b className="text-white">Gamepad</b> — stick izquierdo para girar, RT acelerar, LT frenar, A derrape.</p>
        </div>
        <div className="card-dark p-4">
          <h3 className="font-display font-bold text-white mb-2">📱 CONTROLES MÓVIL</h3>
          <p>Botones táctiles en pantalla: ◀ ▶ para girar, ▲ GAS, ▼ FRENO y ⚡ DERRAPE. Funciona en vertical y horizontal. Para la mejor experiencia, gira el teléfono a horizontal.</p>
        </div>
        <div className="card-dark p-4">
          <h3 className="font-display font-bold text-white mb-2">🏁 CARRERAS</h3>
          <p>Saldrás desde parrilla tras el semáforo. Cuidado con el daño: los golpes reducen tu rendimiento. Pégate a un rival para ganar <b className="text-[#d2ff00]">rebufo</b> y adelantar en las rectas. La lluvia reduce el agarre un 22% — frena antes.</p>
        </div>
        <div className="card-dark p-4">
          <h3 className="font-display font-bold text-white mb-2">📈 PROGRESIÓN</h3>
          <p>Gana dinero y XP en cada carrera. Sube de nivel para desbloquear vehículos, cómpralos en el garage y mejora motor, frenos, neumáticos y aerodinámica. Los campeonatos reparten puntos (25-18-15-12-10-8-6-4-2) y grandes premios.</p>
        </div>
        <div className="card-dark p-4">
          <h3 className="font-display font-bold text-white mb-2">💾 GUARDADO</h3>
          <p>Tu progreso se guarda automáticamente en este navegador (localStorage). No se sincroniza entre dispositivos; borrar los datos del navegador elimina la partida.</p>
        </div>
      </div>
    </div>
  );
}
