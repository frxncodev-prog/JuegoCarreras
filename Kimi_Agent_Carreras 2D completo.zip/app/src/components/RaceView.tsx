import { useEffect, useRef, useState } from 'react';
import { RaceManager, type RaceConfig } from '../game/race';
import { Renderer } from '../game/render';
import { InputManager, isTouchDevice } from '../game/input';
import { GameAudio } from '../game/audio';

interface Props {
  cfg: RaceConfig;
  onFinish: (race: RaceManager) => void;
  onQuit: () => void;
}

export default function RaceView({ cfg, onFinish, onQuit }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const raceRef = useRef<RaceManager | null>(null);
  const inputRef = useRef<InputManager | null>(null);
  const audioRef = useRef<GameAudio | null>(null);
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);
  const [touchMode] = useState(isTouchDevice);
  const finishedRef = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const g = canvas.getContext('2d')!;
    const race = new RaceManager(cfg);
    raceRef.current = race;
    const renderer = new Renderer();
    const input = new InputManager();
    inputRef.current = input;
    const audio = new GameAudio();
    audioRef.current = audio;
    race.onBeep = (f, d) => audio.beep(f, d ?? 0.12);
    race.onThud = (i) => { audio.thud(i); renderer.shake = Math.min(1, i * 0.06); };
    input.onPause = () => { pausedRef.current = true; setPaused(true); };
    // posición inicial de cámara
    renderer.camX = race.player.x; renderer.camY = race.player.y;

    const startAudio = () => { audio.ensure(); audio.startEngine(); };
    window.addEventListener('pointerdown', startAudio, { once: true });
    window.addEventListener('keydown', startAudio, { once: true });

    let raf = 0, last = performance.now(), acc = 0;
    const DT = 1 / 60;
    let finishTimer = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(canvas.clientWidth * dpr);
      canvas.height = Math.floor(canvas.clientHeight * dpr);
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const W = canvas.clientWidth, H = canvas.clientHeight;
      if (W === 0 || H === 0) return;
      let frame = Math.min(0.1, (now - last) / 1000);
      last = now;
      if (!pausedRef.current) {
        acc += frame;
        const inp = input.read();
        while (acc >= DT) {
          race.step(DT, inp);
          acc -= DT;
        }
        if (race.state === 'finished' && !finishedRef.current) {
          finishedRef.current = true;
          finishTimer = 2.4;
        }
        if (finishTimer > 0) {
          finishTimer -= frame;
          if (finishTimer <= 0) { onFinish(race); return; }
        }
        audio.updateEngine(race.player.speedKmh(), race.player.eff().topSpeed * 3.6, race.player.drifting, race.player.offTrack);
      }
      renderer.draw(g, W, H, race, pausedRef.current ? 0.0001 : frame);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      input.destroy();
      audio.stopEngine();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resume = () => { pausedRef.current = false; setPaused(false); };

  const tBtn = (key: keyof InputManager['touch'], label: string, cls: string, sub?: string) => (
    <button
      key={key}
      className={`touch-btn ${cls}`}
      onPointerDown={(e) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); if (inputRef.current) inputRef.current.touch[key] = true; }}
      onPointerUp={() => { if (inputRef.current) inputRef.current.touch[key] = false; }}
      onPointerCancel={() => { if (inputRef.current) inputRef.current.touch[key] = false; }}
      onPointerLeave={() => { if (inputRef.current) inputRef.current.touch[key] = false; }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}{sub && <span className="text-[10px] block opacity-70">{sub}</span>}
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black select-none overflow-hidden" style={{ touchAction: 'none' }}>
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* botón pausa */}
      <button
        onClick={() => { pausedRef.current = true; setPaused(true); }}
        className="absolute top-3 left-1/2 -translate-x-1/2 z-20 w-11 h-11 rounded-full bg-white/10 backdrop-blur text-white font-bold border border-white/20 active:bg-white/25"
        aria-label="Pausa"
      >II</button>

      {/* controles táctiles */}
      {touchMode && !paused && (
        <>
          <div className="absolute bottom-0 left-0 z-20 flex gap-3 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
            {tBtn('left', '◀', 'w-[72px] h-[72px] text-2xl')}
            {tBtn('right', '▶', 'w-[72px] h-[72px] text-2xl')}
          </div>
          <div className="absolute bottom-0 right-0 z-20 flex items-end gap-3 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
            {tBtn('handbrake', '⚡', 'w-[56px] h-[56px] text-lg', 'DERRAPE')}
            {tBtn('brake', '▼', 'w-[72px] h-[72px] text-2xl', 'FRENO')}
            {tBtn('throttle', '▲', 'w-[84px] h-[92px] text-3xl bg-[#3834ff]/40 border-[#3834ff]/60', 'GAS')}
          </div>
        </>
      )}

      {/* menú de pausa */}
      {paused && (
        <div className="absolute inset-0 z-30 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center gap-4 p-6">
          <h2 className="font-display text-4xl font-black text-white tracking-wide">PAUSA</h2>
          <div className="text-white/50 text-sm mb-2">{cfg.mode === 'timetrial' ? 'Contrarreloj' : 'Carrera'} — {cfg.weather.name}</div>
          <button onClick={resume} className="menu-btn bg-[#3834ff] text-white w-64">CONTINUAR</button>
          <button onClick={() => { audioRef.current?.setMuted(!audioRef.current?.muted); }} className="menu-btn bg-white/10 text-white w-64">
            {audioRef.current?.muted ? 'SONIDO: OFF' : 'SONIDO: ON'}
          </button>
          <button onClick={onQuit} className="menu-btn bg-white/10 text-[#ff624d] w-64">ABANDONAR CARRERA</button>
          {!touchMode && (
            <div className="text-white/40 text-xs mt-4 text-center leading-relaxed">
              WASD / Flechas — conducir · Espacio — freno de mano · Esc — pausa<br />Gamepad: stick izquierdo, RT/LT, A derrape
            </div>
          )}
        </div>
      )}
    </div>
  );
}
