import { useEffect, useState } from 'react';
import RaceView from './components/RaceView';
import { HomeScreen, SetupScreen, GarageScreen, ChampScreen, ResultsScreen, HelpScreen, type Screen } from './components/screens';
import { loadSave, storeSave, type SaveData } from './game/save';
import { POINTS, CHAMPIONSHIPS } from './game/data';
import type { RaceManager } from './game/race';

export default function App() {
  const [save, setSaveState] = useState<SaveData>(loadSave);
  const [screen, setScreen] = useState<Screen>({ name: 'home' });

  const setSave = (s: SaveData) => { setSaveState(s); storeSave(s); };
  const ctx = { save, setSave, go: setScreen };

  useEffect(() => { storeSave(save); }, []);

  const onRaceFinish = (race: RaceManager) => {
    const rewards = race.rewards();
    const s: SaveData = JSON.parse(JSON.stringify(save));
    s.money += rewards.money;
    s.xp += rewards.xp;
    s.racesDone += 1;
    if (race.playerPos === 1 && race.cfg.mode !== 'timetrial') s.wins += 1;
    // récord de vuelta
    if (race.player.bestLap > 0) {
      const key = `${race.cfg.trackId}:${race.cfg.category}`;
      if (!s.bestTimes[key] || race.player.bestLap < s.bestTimes[key]) s.bestTimes[key] = Math.round(race.player.bestLap);
    }
    // puntos de campeonato
    let champSummary: string | undefined;
    if (race.cfg.mode === 'championship' && s.champ) {
      const order = race.finalEntries;
      order.forEach((e, i) => {
        const st = s.champ!.standings.find(x => x.name === e.name);
        if (st) st.points += POINTS[i] ?? 0;
      });
      s.champ.raceIdx += 1;
      const chDef = CHAMPIONSHIPS.find(c => c.id === s.champ!.champId);
      if (chDef) {
        const sorted = [...s.champ.standings].sort((a, b) => b.points - a.points);
        const rank = sorted.findIndex(x => x.isPlayer) + 1;
        champSummary = s.champ.raceIdx >= chDef.tracks.length
          ? `Campeonato completado — posición final: P${rank}. Recoge tu premio.`
          : `Vas P${rank} en el campeonato. Próxima: carrera ${s.champ.raceIdx + 1}/${chDef.tracks.length}.`;
      }
    }
    setSave(s);
    setScreen({ name: 'results', race, rewards, champSummary });
  };

  switch (screen.name) {
    case 'home': return <HomeScreen ctx={ctx} />;
    case 'setup': return <SetupScreen ctx={ctx} mode={screen.mode} />;
    case 'garage': return <GarageScreen ctx={ctx} />;
    case 'champ': return <ChampScreen ctx={ctx} />;
    case 'help': return <HelpScreen ctx={ctx} />;
    case 'results': return <ResultsScreen ctx={ctx} race={screen.race} rewards={screen.rewards} champSummary={screen.champSummary} />;
    case 'race': return (
      <RaceView
        key={JSON.stringify({ t: screen.cfg.trackId, v: screen.cfg.vehicleId, w: screen.cfg.weather.id, r: Math.random() })}
        cfg={{ ...screen.cfg, save }}
        onFinish={onRaceFinish}
        onQuit={() => setScreen(screen.cfg.mode === 'championship' ? { name: 'champ' } : { name: 'home' })}
      />
    );
  }
}
