// ============================================================
// Sistema de partículas con pooling (humo, polvo, chispas, lluvia)
// ============================================================
export interface Particle {
  active: boolean; type: number; // 0 humo, 1 polvo, 2 chispa, 3 spray lluvia
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number;
}

const MAX = 420;

export class Particles {
  pool: Particle[] = [];
  constructor() {
    for (let i = 0; i < MAX; i++)
      this.pool.push({ active: false, type: 0, x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 1, size: 1 });
  }
  emit(type: number, x: number, y: number, vx: number, vy: number, life: number, size: number) {
    for (const p of this.pool) {
      if (!p.active) {
        p.active = true; p.type = type; p.x = x; p.y = y;
        p.vx = vx + (Math.random() - 0.5) * 2; p.vy = vy + (Math.random() - 0.5) * 2;
        p.life = life; p.maxLife = life; p.size = size * (0.7 + Math.random() * 0.6);
        return;
      }
    }
  }
  update(dt: number) {
    for (const p of this.pool) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) { p.active = false; continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.type === 2) { p.vy += 20 * dt; } // gravedad en chispas
      else { p.vx *= (1 - dt * 2); p.vy *= (1 - dt * 2); p.size += dt * 4; }
    }
  }
  draw(g: CanvasRenderingContext2D, toScreen: (x: number, y: number) => [number, number], scale: number) {
    for (const p of this.pool) {
      if (!p.active) continue;
      const t = p.life / p.maxLife;
      const [sx, sy] = toScreen(p.x, p.y);
      const s = p.size * scale;
      if (p.type === 0) { // humo
        g.fillStyle = `rgba(200,200,200,${0.35 * t})`;
        g.beginPath(); g.arc(sx, sy, s, 0, 7); g.fill();
      } else if (p.type === 1) { // polvo
        g.fillStyle = `rgba(150,125,80,${0.4 * t})`;
        g.beginPath(); g.arc(sx, sy, s, 0, 7); g.fill();
      } else if (p.type === 2) { // chispa
        g.fillStyle = `rgba(255,${180 + Math.floor(60 * t)},60,${t})`;
        g.fillRect(sx - 1.5, sy - 1.5, 3, 3);
      } else { // spray de lluvia
        g.fillStyle = `rgba(180,200,220,${0.22 * t})`;
        g.beginPath(); g.arc(sx, sy, s * 0.8, 0, 7); g.fill();
      }
    }
  }
}
