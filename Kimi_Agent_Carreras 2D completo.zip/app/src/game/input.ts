// ============================================================
// Entrada unificada: teclado + táctil + gamepad
// ============================================================
import type { CarInput } from './car';

export class InputManager {
  keys = new Set<string>();
  touch = { left: false, right: false, throttle: false, brake: false, handbrake: false };
  onPause: (() => void) | null = null;
  private prevPauseBtn = false;

  constructor() {
    window.addEventListener('keydown', this.kd);
    window.addEventListener('keyup', this.ku);
  }
  destroy() {
    window.removeEventListener('keydown', this.kd);
    window.removeEventListener('keyup', this.ku);
  }
  private kd = (e: KeyboardEvent) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault();
    if ((e.key === 'Escape' || e.key === 'p' || e.key === 'P') && this.onPause) this.onPause();
    this.keys.add(e.key.toLowerCase());
  };
  private ku = (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase());

  read(): CarInput {
    const k = this.keys;
    let steer = 0, throttle = 0, brake = 0, hb = false;
    // teclado
    if (k.has('a') || k.has('arrowleft')) steer -= 1;
    if (k.has('d') || k.has('arrowright')) steer += 1;
    if (k.has('w') || k.has('arrowup')) throttle = 1;
    if (k.has('s') || k.has('arrowdown')) brake = 1;
    if (k.has(' ')) hb = true;
    // táctil
    if (this.touch.left) steer -= 1;
    if (this.touch.right) steer += 1;
    if (this.touch.throttle) throttle = 1;
    if (this.touch.brake) brake = 1;
    if (this.touch.handbrake) hb = true;
    // gamepad
    const pads = navigator.getGamepads?.() ?? [];
    for (const gp of pads) {
      if (!gp || !gp.connected) continue;
      const ax = gp.axes[0] ?? 0;
      if (Math.abs(ax) > 0.12) steer += ax;
      const rt = gp.buttons[7]?.value ?? 0, lt = gp.buttons[6]?.value ?? 0;
      if (rt > 0.1) throttle = Math.max(throttle, rt);
      if (lt > 0.1) brake = Math.max(brake, lt);
      if (gp.buttons[0]?.pressed || gp.buttons[1]?.pressed) hb = true;
      if (gp.buttons[2]?.pressed) brake = 1;
      if (gp.buttons[3]?.pressed) throttle = 1;
      const pauseBtn = gp.buttons[9]?.pressed ?? false;
      if (pauseBtn && !this.prevPauseBtn && this.onPause) this.onPause();
      this.prevPauseBtn = pauseBtn;
      break;
    }
    steer = Math.max(-1, Math.min(1, steer));
    return { throttle, brake, steer, handbrake: hb };
  }
}

export const isTouchDevice = () =>
  typeof window !== 'undefined' && (('ontouchstart' in window) || navigator.maxTouchPoints > 0);
