// ============================================================
// APEX RUSH RACING — Datos del juego (categorías, vehículos, circuitos)
// Todos los nombres son ficticios.
// ============================================================

export interface VehicleStats {
  topSpeed: number; // km/h
  accel: number;    // m/s^2 base
  grip: number;     // coeficiente de agarre lateral
  brake: number;    // m/s^2
  weight: number;   // kg (afecta colisiones y agilidad)
}

export interface Vehicle {
  id: string;
  name: string;
  category: string;
  stats: VehicleStats;
  price: number;       // 0 = disponible desde el inicio
  unlockLevel: number; // nivel de piloto requerido para comprar
  colors: [string, string]; // color principal, color secundario
  desc: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string; // letra distintiva
  color: string;
  desc: string;
}

export const CATEGORIES: Category[] = [
  { id: 'kart',   name: 'Karting',    icon: 'K', color: '#d2ff00', desc: 'Ligeros y nerviosos. Pura agilidad.' },
  { id: 'touring',name: 'Turismos',   icon: 'T', color: '#4da3ff', desc: 'Equilibrio y contacto rueda a rueda.' },
  { id: 'gt3',    name: 'GT3',        icon: 'G', color: '#ff624d', desc: 'Gran turismo con carga aerodinámica.' },
  { id: 'super',  name: 'Supercars',  icon: 'S', color: '#c07bff', desc: 'Velocidad brutal en circuito.' },
  { id: 'f2',     name: 'Fórmula 2',  icon: 'F2', color: '#00e5c0', desc: 'Monoplazas de precisión quirúrgica.' },
  { id: 'f1',     name: 'Fórmula 1',  icon: 'F1', color: '#ffd23e', desc: 'La élite absoluta del motor.' },
];

// stats: topSpeed km/h, accel m/s², grip (mayor = más agarre), brake m/s², weight kg
export const VEHICLES: Vehicle[] = [
  // ---------- KARTING ----------
  { id: 'kart1', name: 'Cometa 100', category: 'kart', price: 0, unlockLevel: 1, colors: ['#d2ff00', '#111111'],
    stats: { topSpeed: 118, accel: 11.5, grip: 1.25, brake: 15, weight: 170 }, desc: 'El kart de siempre. Directo y honesto.' },
  { id: 'kart2', name: 'Flecha RX', category: 'kart', price: 3500, unlockLevel: 2, colors: ['#ff4d4d', '#f3f3f3'],
    stats: { topSpeed: 128, accel: 12.5, grip: 1.3, brake: 16, weight: 165 }, desc: 'Chasis rígido, respuesta instantánea.' },
  { id: 'kart3', name: 'Vortex KZ', category: 'kart', price: 8000, unlockLevel: 4, colors: ['#3834ff', '#d2ff00'],
    stats: { topSpeed: 138, accel: 13.5, grip: 1.36, brake: 17, weight: 160 }, desc: 'Caja de cambios y mucha rabia.' },
  { id: 'kart4', name: 'Dragón S1', category: 'kart', price: 15000, unlockLevel: 6, colors: ['#00e5c0', '#0a0a0a'],
    stats: { topSpeed: 148, accel: 14.5, grip: 1.42, brake: 18, weight: 155 }, desc: 'El kart más rápido del paddock.' },
  // ---------- TURISMOS ----------
  { id: 'tour1', name: 'Lince 1.6T', category: 'touring', price: 0, unlockLevel: 1, colors: ['#4da3ff', '#ffffff'],
    stats: { topSpeed: 205, accel: 8.2, grip: 1.0, brake: 13, weight: 1180 }, desc: 'Compacto de copa. Fácil de llevar.' },
  { id: 'tour2', name: 'Sable GT-R', category: 'touring', price: 22000, unlockLevel: 3, colors: ['#ffd23e', '#1a1a1a'],
    stats: { topSpeed: 222, accel: 9.0, grip: 1.05, brake: 13.5, weight: 1150 }, desc: 'Tracción y equilibrio de carreras.' },
  { id: 'tour3', name: 'Aquila TCR', category: 'touring', price: 42000, unlockLevel: 6, colors: ['#ff624d', '#101010'],
    stats: { topSpeed: 236, accel: 9.8, grip: 1.12, brake: 14.5, weight: 1120 }, desc: 'Homologado para la batalla.' },
  { id: 'tour4', name: 'Titán Cupra-X', category: 'touring', price: 68000, unlockLevel: 9, colors: ['#c07bff', '#0d0d0d'],
    stats: { topSpeed: 250, accel: 10.6, grip: 1.18, brake: 15.5, weight: 1100 }, desc: 'El turismo definitivo.' },
  // ---------- GT3 ----------
  { id: 'gt31', name: 'Auriga GT', category: 'gt3', price: 60000, unlockLevel: 4, colors: ['#ff624d', '#111111'],
    stats: { topSpeed: 268, accel: 10.2, grip: 1.28, brake: 17, weight: 1300 }, desc: 'GT de aspiración. Noble y rápido.' },
  { id: 'gt32', name: 'Raptor 650', category: 'gt3', price: 95000, unlockLevel: 7, colors: ['#d2ff00', '#151515'],
    stats: { topSpeed: 278, accel: 10.8, grip: 1.33, brake: 17.8, weight: 1280 }, desc: 'Alerón grande, corazón grande.' },
  { id: 'gt33', name: 'Centauro RS', category: 'gt3', price: 140000, unlockLevel: 10, colors: ['#3834ff', '#f3f3f3'],
    stats: { topSpeed: 288, accel: 11.5, grip: 1.4, brake: 18.6, weight: 1260 }, desc: 'Equilibrio de carrera perfecto.' },
  { id: 'gt34', name: 'Furia Nera', category: 'gt3', price: 200000, unlockLevel: 13, colors: ['#1a1a1a', '#ff4d4d'],
    stats: { topSpeed: 298, accel: 12.2, grip: 1.47, brake: 19.4, weight: 1240 }, desc: 'La bestia del GT3.' },
  // ---------- SUPERCARS ----------
  { id: 'sup1', name: 'Véloce S', category: 'super', price: 120000, unlockLevel: 6, colors: ['#c07bff', '#0a0a0a'],
    stats: { topSpeed: 305, accel: 11.8, grip: 1.3, brake: 17, weight: 1350 }, desc: 'Superdeportivo de calle, alma de pista.' },
  { id: 'sup2', name: 'Orca LP-700', category: 'super', price: 190000, unlockLevel: 9, colors: ['#00e5c0', '#111111'],
    stats: { topSpeed: 322, accel: 12.8, grip: 1.36, brake: 17.6, weight: 1320 }, desc: 'Silueta de tiburón, mordisco real.' },
  { id: 'sup3', name: 'Zephyr X', category: 'super', price: 290000, unlockLevel: 12, colors: ['#ffd23e', '#0d0d0d'],
    stats: { topSpeed: 338, accel: 13.8, grip: 1.42, brake: 18.4, weight: 1280 }, desc: 'Fibra de carbono por todas partes.' },
  { id: 'sup4', name: 'Hiperion GT1', category: 'super', price: 420000, unlockLevel: 15, colors: ['#ff4d4d', '#101010'],
    stats: { topSpeed: 355, accel: 15.0, grip: 1.5, brake: 19.2, weight: 1250 }, desc: 'Casi un prototipo. Casi ilegal.' },
  // ---------- FÓRMULA 2 ----------
  { id: 'f21', name: 'Astra F2', category: 'f2', price: 250000, unlockLevel: 8, colors: ['#00e5c0', '#0a0a0a'],
    stats: { topSpeed: 320, accel: 15.5, grip: 1.85, brake: 24, weight: 755 }, desc: 'Monoplaza escuela de campeones.' },
  { id: 'f22', name: 'Pulsar 02', category: 'f2', price: 330000, unlockLevel: 11, colors: ['#3834ff', '#d2ff00'],
    stats: { topSpeed: 328, accel: 16.2, grip: 1.92, brake: 25, weight: 750 }, desc: 'Carga aerodinámica constante.' },
  { id: 'f23', name: 'Nébula JR', category: 'f2', price: 430000, unlockLevel: 14, colors: ['#f3f3f3', '#3834ff'],
    stats: { topSpeed: 336, accel: 16.9, grip: 2.0, brake: 26, weight: 745 }, desc: 'El escalón antes de la élite.' },
  { id: 'f24', name: 'Quasar F2X', category: 'f2', price: 560000, unlockLevel: 17, colors: ['#ff624d', '#0d0d0d'],
    stats: { topSpeed: 344, accel: 17.6, grip: 2.08, brake: 27, weight: 740 }, desc: 'F2 experimental, ritmo de F1.' },
  // ---------- FÓRMULA 1 ----------
  { id: 'f11', name: 'Éclair E1', category: 'f1', price: 700000, unlockLevel: 12, colors: ['#ffd23e', '#111111'],
    stats: { topSpeed: 340, accel: 18.5, grip: 2.25, brake: 30, weight: 798 }, desc: 'Tu primer Fórmula 1.' },
  { id: 'f12', name: 'Meridiano M-01', category: 'f1', price: 900000, unlockLevel: 15, colors: ['#d2ff00', '#0a0a0a'],
    stats: { topSpeed: 350, accel: 19.4, grip: 2.34, brake: 31.5, weight: 795 }, desc: 'Híbrido, afilado, implacable.' },
  { id: 'f13', name: 'Solaris SF-9', category: 'f1', price: 1200000, unlockLevel: 18, colors: ['#ff4d4d', '#1a1a1a'],
    stats: { topSpeed: 360, accel: 20.4, grip: 2.44, brake: 33, weight: 792 }, desc: 'Hecho para dominar parrillas.' },
  { id: 'f14', name: 'Apolo X-Prime', category: 'f1', price: 1600000, unlockLevel: 21, colors: ['#c07bff', '#050505'],
    stats: { topSpeed: 372, accel: 21.5, grip: 2.56, brake: 34.5, weight: 788 }, desc: 'La cúspide. Sin concesiones.' },
];

export const vehiclesByCategory = (cat: string) => VEHICLES.filter(v => v.category === cat);
export const vehicleById = (id: string) => VEHICLES.find(v => v.id === id)!;

// ============================================================
// CIRCUITOS — puntos de control (metros) de una spline cerrada
// ============================================================
export interface TrackDef {
  id: string;
  name: string;
  country: string;
  points: [number, number][];
  width: number;        // ancho de asfalto en metros
  laps: number;         // vueltas por defecto
  theme: 'costa' | 'bosque' | 'desierto' | 'montana' | 'ciudad' | 'llanura';
  desc: string;
}

export const TRACKS: TrackDef[] = [
  {
    id: 'costa', name: 'Costa Azul', country: 'Riviera', width: 13, laps: 3, theme: 'costa',
    desc: 'Rápido y fluido junto al mar.',
    points: [[0,0],[220,-30],[400,30],[480,160],[400,290],[240,320],[120,260],[40,340],[-80,360],[-180,280],[-140,150],[-60,80]],
  },
  {
    id: 'volcan', name: 'Volcán Rojo', country: 'Tierra del Fuego', width: 12, laps: 3, theme: 'desierto',
    desc: 'Curvas ciegas entre ceniza y roca.',
    points: [[0,0],[180,-80],[340,-40],[420,80],[380,200],[460,300],[380,420],[220,400],[140,480],[-20,460],[-120,380],[-60,280],[-160,200],[-140,80],[-60,40]],
  },
  {
    id: 'bosque', name: 'Bosque Negro', country: 'Nordheim', width: 11, laps: 3, theme: 'bosque',
    desc: 'Estrecho, técnico, sin perdón.',
    points: [[0,0],[150,-60],[280,-20],[330,90],[260,170],[300,260],[220,340],[100,320],[40,410],[-80,430],[-160,360],[-120,260],[-200,180],[-180,70],[-80,30]],
  },
  {
    id: 'delta', name: 'Delta Urbano', country: 'Puerto Delta', width: 14, laps: 4, theme: 'ciudad',
    desc: 'Callejero de 90 grados y muros.',
    points: [[0,0],[260,0],[260,180],[420,180],[420,340],[200,340],[200,460],[0,460],[0,300],[-160,300],[-160,140],[0,140]],
  },
  {
    id: 'alpino', name: 'Pasodel Águila', country: 'Cordillera', width: 12, laps: 3, theme: 'montana',
    desc: 'Subidas, bajadas y horquillas.',
    points: [[0,0],[200,-100],[360,-60],[440,60],[380,160],[460,240],[420,360],[300,340],[240,440],[120,480],[20,400],[-80,440],[-180,360],[-140,240],[-220,140],[-160,40],[-60,60]],
  },
  {
    id: 'llanura', name: 'Anillo Dorado', country: 'Pampa', width: 15, laps: 3, theme: 'llanura',
    desc: 'El óvalo rápido de los récords.',
    points: [[0,0],[260,-40],[440,20],[540,140],[500,280],[360,360],[180,380],[20,320],[-100,340],[-200,260],[-180,120],[-80,40]],
  },
  {
    id: 'lago', name: 'Lago Espejo', country: 'Valle Alto', width: 13, laps: 3, theme: 'costa',
    desc: 'Rodillo veloz junto al agua.',
    points: [[0,0],[240,-60],[420,-20],[520,100],[480,220],[560,320],[480,440],[320,420],[240,500],[80,520],[-40,440],[-140,460],[-240,380],[-200,240],[-260,120],[-160,20],[-60,60]],
  },
  {
    id: 'reloj', name: 'Reloj de Arena', country: 'Dunas', width: 12, laps: 4, theme: 'desierto',
    desc: 'Cruces y cambios de ritmo.',
    points: [[0,0],[200,-80],[380,-40],[460,80],[400,180],[480,280],[400,400],[260,380],[200,280],[120,340],[40,280],[100,180],[0,120],[-120,160],[-200,80],[-140,-20],[-40,20]],
  },
];

export const trackById = (id: string) => TRACKS.find(t => t.id === id)!;

// ============================================================
// MEJORAS
// ============================================================
export interface UpgradeDef { id: string; name: string; desc: string; icon: string }
export const UPGRADES: UpgradeDef[] = [
  { id: 'engine', name: 'Motor',        icon: '⚙', desc: '+Velocidad punta y aceleración por nivel.' },
  { id: 'brakes', name: 'Frenos',       icon: '◉', desc: '+Potencia de frenada por nivel.' },
  { id: 'tires',  name: 'Neumáticos',   icon: '◎', desc: '+Agarre en seco y en lluvia por nivel.' },
  { id: 'aero',   name: 'Aerodinámica', icon: '✦', desc: '+Estabilidad en curva y rebufo por nivel.' },
];
export const UPGRADE_MAX = 5;
export const upgradeCost = (vehiclePrice: number, level: number) =>
  Math.round((vehiclePrice * 0.12 + 2500) * (level + 1) * 1.15);

// ============================================================
// CAMPEONATOS
// ============================================================
export const POINTS = [25, 18, 15, 12, 10, 8, 6, 4, 2, 1];
export interface ChampionshipDef { id: string; name: string; category: string; tracks: string[]; prize: number }
export const CHAMPIONSHIPS: ChampionshipDef[] = [
  { id: 'ch_kart', name: 'Copa Karting', category: 'kart', prize: 20000,
    tracks: ['delta', 'bosque', 'reloj', 'costa'] },
  { id: 'ch_tour', name: 'Trofeo Turismos', category: 'touring', prize: 60000,
    tracks: ['costa', 'delta', 'llanura', 'volcan', 'bosque'] },
  { id: 'ch_gt3', name: 'GT3 World Series', category: 'gt3', prize: 150000,
    tracks: ['lago', 'alpino', 'llanura', 'costa', 'volcan'] },
  { id: 'ch_super', name: 'Liga Supercars', category: 'super', prize: 260000,
    tracks: ['llanura', 'lago', 'reloj', 'alpino', 'delta'] },
  { id: 'ch_f2', name: 'F2 Grand Trophy', category: 'f2', prize: 450000,
    tracks: ['bosque', 'volcan', 'lago', 'alpino', 'costa'] },
  { id: 'ch_f1', name: 'Apex F1 Championship', category: 'f1', prize: 900000,
    tracks: ['costa', 'alpino', 'delta', 'lago', 'volcan', 'llanura'] },
];

export const DIFFICULTIES = [
  { id: 'easy',   name: 'Novato',    aiSpeed: 0.86, aiMistakes: 0.35, desc: 'IA suave, ideal para aprender.' },
  { id: 'medium', name: 'Profesional', aiSpeed: 0.94, aiMistakes: 0.18, desc: 'Ritmo real de carrera.' },
  { id: 'hard',   name: 'Leyenda',   aiSpeed: 1.0, aiMistakes: 0.06, desc: 'La IA no regala nada.' },
] as const;
export type DifficultyId = typeof DIFFICULTIES[number]['id'];

export const XP_PER_LEVEL = 1000;
export const levelFromXp = (xp: number) => 1 + Math.floor(xp / XP_PER_LEVEL);
export const xpProgress = (xp: number) => (xp % XP_PER_LEVEL) / XP_PER_LEVEL;

export interface WeatherOption { id: string; name: string; rain: number; night: number; desc: string }
export const WEATHERS: WeatherOption[] = [
  { id: 'day',     name: 'Día soleado',  rain: 0, night: 0,   desc: 'Agarre perfecto.' },
  { id: 'sunset',  name: 'Atardecer',    rain: 0, night: 0.4, desc: 'Luz dorada, agarre perfecto.' },
  { id: 'night',   name: 'Noche',        rain: 0, night: 1,   desc: 'Faros encendidos.' },
  { id: 'rain',    name: 'Lluvia',       rain: 1, night: 0.25,desc: 'Agarre reducido un 22%.' },
  { id: 'storm',   name: 'Tormenta nocturna', rain: 1, night: 1, desc: 'El reto máximo: mojado y oscuro.' },
];
