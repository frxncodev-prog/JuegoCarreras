// ============================================================
// Audio sintético (WebAudio) — motor, derrape, impactos, semáforo
// ============================================================
export class GameAudio {
  ctx: AudioContext | null = null;
  engineOsc: OscillatorNode | null = null;
  engineOsc2: OscillatorNode | null = null;
  engineGain: GainNode | null = null;
  skidSrc: AudioBufferSourceNode | null = null;
  skidGain: GainNode | null = null;
  muted = false;
  master: GainNode | null = null;

  ensure() {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
      } catch { return; }
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.5;
  }
  startEngine() {
    this.ensure(); if (!this.ctx || this.engineOsc) return;
    const c = this.ctx;
    this.engineGain = c.createGain(); this.engineGain.gain.value = 0.05;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900;
    this.engineOsc = c.createOscillator(); this.engineOsc.type = 'sawtooth'; this.engineOsc.frequency.value = 60;
    this.engineOsc2 = c.createOscillator(); this.engineOsc2.type = 'square'; this.engineOsc2.frequency.value = 30;
    const g2 = c.createGain(); g2.gain.value = 0.4;
    this.engineOsc.connect(f); this.engineOsc2.connect(g2); g2.connect(f);
    f.connect(this.engineGain); this.engineGain.connect(this.master!);
    this.engineOsc.start(); this.engineOsc2.start();
    // ruido para derrapes
    const len = c.sampleRate;
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.skidSrc = c.createBufferSource(); this.skidSrc.buffer = buf; this.skidSrc.loop = true;
    const sf = c.createBiquadFilter(); sf.type = 'bandpass'; sf.frequency.value = 1200; sf.Q.value = 1.2;
    this.skidGain = c.createGain(); this.skidGain.gain.value = 0;
    this.skidSrc.connect(sf); sf.connect(this.skidGain); this.skidGain.connect(this.master!);
    this.skidSrc.start();
  }
  updateEngine(speedKmh: number, topKmh: number, drifting: boolean, offTrack: boolean) {
    if (!this.ctx || !this.engineOsc) return;
    const r = 0.25 + Math.min(1, speedKmh / Math.max(60, topKmh)) * 0.75;
    const f = 50 + r * r * 210;
    this.engineOsc.frequency.setTargetAtTime(f, this.ctx.currentTime, 0.05);
    this.engineOsc2!.frequency.setTargetAtTime(f / 2, this.ctx.currentTime, 0.05);
    this.engineGain!.gain.setTargetAtTime(0.045 + r * 0.05, this.ctx.currentTime, 0.1);
    this.skidGain!.gain.setTargetAtTime(drifting ? 0.09 : offTrack ? 0.04 : 0, this.ctx.currentTime, 0.08);
  }
  stopEngine() {
    try {
      this.engineOsc?.stop(); this.engineOsc2?.stop(); this.skidSrc?.stop();
    } catch { /* noop */ }
    this.engineOsc = null; this.engineOsc2 = null; this.skidSrc = null;
  }
  beep(freq: number, dur = 0.12, vol = 0.25) {
    this.ensure(); if (!this.ctx) return;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = 'square'; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
    o.connect(g); g.connect(this.master!);
    o.start(); o.stop(this.ctx.currentTime + dur);
  }
  thud(intensity: number) {
    this.ensure(); if (!this.ctx) return;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(120, this.ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.18);
    const v = Math.min(0.5, 0.08 + intensity * 0.05);
    g.gain.setValueAtTime(v, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
    o.connect(g); g.connect(this.master!);
    o.start(); o.stop(this.ctx.currentTime + 0.2);
  }
}
