// ============================================================
// Guardado de progreso (localStorage del navegador)
// ============================================================
export interface ChampSave {
  champId: string;
  vehicleId: string;               // vehículo elegido para el campeonato
  raceIdx: number;                 // próxima carrera a disputar
  standings: { name: string; points: number; isPlayer: boolean }[];
}

export interface SaveData {
  money: number;
  xp: number;
  owned: string[];                          // ids de vehículos comprados
  upgrades: Record<string, { engine: number; brakes: number; tires: number; aero: number }>;
  bestTimes: Record<string, number>;        // `${trackId}:${category}` -> ms
  champ: ChampSave | null;
  champsWon: string[];
  racesDone: number;
  wins: number;
}

const KEY = 'apex-rush-save-v1';

export const defaultSave = (): SaveData => ({
  money: 15000, xp: 0, owned: ['kart1', 'tour1'], upgrades: {}, bestTimes: {},
  champ: null, champsWon: [], racesDone: 0, wins: 0,
});

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    return { ...defaultSave(), ...JSON.parse(raw) };
  } catch { return defaultSave(); }
}

export function storeSave(s: SaveData) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* almacenamiento lleno */ }
}

export function resetSave(): SaveData {
  const d = defaultSave();
  storeSave(d);
  return d;
}

export const upOf = (s: SaveData, vehId: string) =>
  s.upgrades[vehId] ?? { engine: 0, brakes: 0, tires: 0, aero: 0 };

export const fmtMoney = (n: number) => '$' + n.toLocaleString('es-ES');
export const fmtTime = (ms: number) => {
  if (!ms || ms <= 0 || !isFinite(ms)) return '--:--.---';
  const m = Math.floor(ms / 60000), s = Math.floor((ms % 60000) / 1000), mm = Math.floor(ms % 1000);
  return `${m}:${s.toString().padStart(2, '0')}.${mm.toString().padStart(3, '0')}`;
};
