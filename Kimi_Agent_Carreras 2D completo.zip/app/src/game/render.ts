// ============================================================
// Renderizado: cámara, coches, clima, día/noche, HUD, minimapa
// ============================================================
import type { Car } from './car';
import type { RaceManager } from './race';
import { fmtTime } from './save';

const THEMES: Record<string, { grass: string; grass2: string; asphalt: string; curbA: string; curbB: string }> = {
  costa:   { grass: '#2e6b3a', grass2: '#3a7d46', asphalt: '#3c3f45', curbA: '#e33', curbB: '#f3f3f3' },
  bosque:  { grass: '#1e4d2b', grass2: '#2a5f38', asphalt: '#35383e', curbA: '#e33', curbB: '#f3f3f3' },
  desierto:{ grass: '#9a7b4f', grass2: '#b08d5c', asphalt: '#43464c', curbA: '#e33', curbB: '#f3f3f3' },
  montana: { grass: '#4a5d3a', grass2: '#5c7048', asphalt: '#3a3d43', curbA: '#e33', curbB: '#f3f3f3' },
  ciudad:  { grass: '#3d3d42', grass2: '#4a4a50', asphalt: '#2e3136', curbA: '#ffd23e', curbB: '#222' },
  llanura: { grass: '#4f7a35', grass2: '#5f8c40', asphalt: '#404349', curbA: '#e33', curbB: '#f3f3f3' },
};

// dimensiones (m) y forma por categoría
const BODY: Record<string, { l: number; w: number; wing: boolean; openWheel: boolean }> = {
  kart:    { l: 2.1, w: 1.5, wing: false, openWheel: true },
  touring: { l: 4.4, w: 1.9, wing: true, openWheel: false },
  gt3:     { l: 4.6, w: 2.0, wing: true, openWheel: false },
  super:   { l: 4.6, w: 2.0, wing: true, openWheel: false },
  f2:      { l: 5.2, w: 1.9, wing: true, openWheel: true },
  f1:      { l: 5.6, w: 2.0, wing: true, openWheel: true },
};

export class Renderer {
  camX = 0; camY = 0; camScale = 2.2;
  shake = 0;
  rainDrops: { x: number; y: number; v: number }[] = [];

  constructor() {
    for (let i = 0; i < 90; i++) this.rainDrops.push({ x: Math.random(), y: Math.random(), v: 0.7 + Math.random() * 0.6 });
  }

  ensurePrerender(race: RaceManager) {
    if (!race.track.off) race.track.prerender(THEMES[race.track.def.theme] ?? THEMES.costa, race.cfg.weather.night);
  }

  draw(g: CanvasRenderingContext2D, W: number, H: number, race: RaceManager, dt: number) {
    this.ensurePrerender(race);
    const p = race.player;
    const night = race.cfg.weather.night;
    const rain = race.cfg.weather.rain;

    // cámara con lookahead y zoom dinámico
    const look = Math.min(30, p.speed() * 0.5);
    const tx = p.x + Math.cos(p.angle) * look;
    const ty = p.y + Math.sin(p.angle) * look;
    const k = Math.min(1, dt * 4);
    this.camX += (tx - this.camX) * k;
    this.camY += (ty - this.camY) * k;
    const baseScale = Math.min(W, H) / 110;
    const targetScale = baseScale * (1.25 - Math.min(0.35, p.speed() / 320));
    this.camScale += (targetScale - this.camScale) * Math.min(1, dt * 2);
    const s = this.camScale;
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 3);
    const shX = (Math.random() - 0.5) * this.shake * 10;
    const shY = (Math.random() - 0.5) * this.shake * 10;
    const toScreen = (x: number, y: number): [number, number] =>
      [(x - this.camX) * s + W / 2 + shX, (y - this.camY) * s + H / 2 + shY];

    // fondo
    g.fillStyle = night > 0.5 ? '#05070c' : '#0b0d10';
    g.fillRect(0, 0, W, H);

    // pista pre-renderizada
    const t = race.track;
    if (t.off) {
      const [ox, oy] = toScreen(t.bounds.minX, t.bounds.minY);
      g.imageSmoothingEnabled = true;
      g.drawImage(t.off, ox, oy, (t.bounds.maxX - t.bounds.minX) * s, (t.bounds.maxY - t.bounds.minY) * s);
    }

    // partículas debajo de los coches
    race.particles.draw(g, toScreen, s * 0.8);

    // coches
    const order = [...race.cars].sort((a, b) => (a.isPlayer ? 1 : 0) - (b.isPlayer ? 1 : 0));
    for (const c of order) this.drawCar(g, c, toScreen, s, night);

    // lluvia
    if (rain > 0) this.drawRain(g, W, H, dt);

    // noche: oscurecer con luz alrededor de coches
    if (night > 0) this.drawNight(g, W, H, race, toScreen, s, night);

    // HUD
    this.drawHUD(g, W, H, race);
  }

  private drawCar(g: CanvasRenderingContext2D, c: Car, toScreen: (x: number, y: number) => [number, number], s: number, night: number) {
    const [sx, sy] = toScreen(c.x, c.y);
    if (sx < -60 || sy < -60 || sx > g.canvas.width + 60 || sy > g.canvas.height + 60) return;
    const body = BODY[c.veh.category] ?? BODY.touring;
    const L = body.l * s, Wd = body.w * s;
    g.save();
    g.translate(sx, sy);
    g.rotate(c.angle);
    // sombra
    g.fillStyle = 'rgba(0,0,0,0.35)';
    g.beginPath(); g.ellipse(1.5, 1.5, L / 2, Wd / 2, 0, 0, 7); g.fill();
    // faros de noche
    if (night > 0.3) {
      const grad = g.createLinearGradient(L / 2, 0, L / 2 + 26 * s * 0.4, 0);
      grad.addColorStop(0, `rgba(255,240,180,${0.25 * night})`);
      grad.addColorStop(1, 'rgba(255,240,180,0)');
      g.fillStyle = grad;
      g.beginPath();
      g.moveTo(L / 2, -Wd / 3); g.lineTo(L / 2 + 12 * s, -Wd); g.lineTo(L / 2 + 12 * s, Wd); g.lineTo(L / 2, Wd / 3);
      g.closePath(); g.fill();
    }
    const wheelW = Math.max(2, 0.42 * s), wheelL = Math.max(3, 0.9 * s);
    const drawWheel = (fx: number, fy: number, steer: boolean) => {
      g.save(); g.translate(fx, fy); if (steer) g.rotate(c.steerVis * 0.5);
      g.fillStyle = '#0a0a0a'; g.fillRect(-wheelL / 2, -wheelW / 2, wheelL, wheelW); g.restore();
    };
    if (body.openWheel) {
      const wo = Wd / 2 + wheelW * 0.2;
      drawWheel(L * 0.32, -wo, true); drawWheel(L * 0.32, wo, true);
      drawWheel(-L * 0.32, -wo, false); drawWheel(-L * 0.32, wo, false);
    } else {
      const wo = Wd / 2 - wheelW * 0.3;
      drawWheel(L * 0.3, -wo, true); drawWheel(L * 0.3, wo, true);
      drawWheel(-L * 0.3, -wo, false); drawWheel(-L * 0.3, wo, false);
    }
    // alerón delantero
    if (body.openWheel && body.wing) {
      g.fillStyle = c.color2;
      g.fillRect(L * 0.42, -Wd * 0.62, Math.max(2, L * 0.07), Wd * 1.24);
    }
    // carrocería
    g.fillStyle = c.color;
    const r = Math.min(L, Wd) * 0.28;
    g.beginPath();
    const bw = body.openWheel ? Wd * 0.55 : Wd;
    (g as any).roundRect(-L / 2, -bw / 2, L, bw, r);
    g.fill();
    // franja/acento
    g.fillStyle = c.color2;
    g.fillRect(-L / 2, -bw * 0.16, L * (body.openWheel ? 0.75 : 1), bw * 0.32);
    // cabina
    g.fillStyle = 'rgba(10,12,16,0.9)';
    const cabL = body.openWheel ? L * 0.22 : L * 0.34;
    const cabX = body.openWheel ? -L * 0.05 : -L * 0.02;
    g.beginPath(); (g as any).roundRect(cabX - cabL / 2, -bw * 0.3, cabL, bw * 0.6, r * 0.6); g.fill();
    // alerón trasero
    if (body.wing) {
      g.fillStyle = c.color2;
      g.fillRect(-L * 0.5, -Wd * (body.openWheel ? 0.55 : 0.5), Math.max(2, L * 0.06), Wd * (body.openWheel ? 1.1 : 1));
    }
    g.restore();
  }

  private drawRain(g: CanvasRenderingContext2D, W: number, H: number, dt: number) {
    g.strokeStyle = 'rgba(170,190,215,0.35)';
    g.lineWidth = 1;
    g.beginPath();
    for (const d of this.rainDrops) {
      d.y += d.v * dt * 1.4;
      d.x += dt * 0.12;
      if (d.y > 1) { d.y = -0.05; d.x = Math.random(); }
      const x = d.x * W, y = d.y * H;
      g.moveTo(x, y); g.lineTo(x - 4, y - 14);
    }
    g.stroke();
  }

  private drawNight(g: CanvasRenderingContext2D, W: number, H: number, race: RaceManager, toScreen: (x: number, y: number) => [number, number], s: number, night: number) {
    const dark = 0.62 * night;
    g.save();
    g.fillStyle = `rgba(2,4,14,${dark})`;
    g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'destination-out';
    for (const c of race.cars) {
      const [sx, sy] = toScreen(c.x, c.y);
      const R = (c.isPlayer ? 62 : 40) * s;
      const grad = g.createRadialGradient(sx, sy, R * 0.2, sx, sy, R);
      grad.addColorStop(0, 'rgba(0,0,0,0.95)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grad;
      g.beginPath(); g.arc(sx, sy, R, 0, 7); g.fill();
    }
    g.restore();
  }

  // ==================== HUD ====================
  private drawHUD(g: CanvasRenderingContext2D, W: number, H: number, race: RaceManager) {
    const p = race.player;
    const isTT = race.cfg.mode === 'timetrial';
    const pad = Math.max(10, Math.min(W, H) * 0.02);
    const big = Math.max(26, Math.min(W, H) * 0.075);
    const med = Math.max(13, Math.min(W, H) * 0.026);
    const small = Math.max(10, Math.min(W, H) * 0.02);

    g.textBaseline = 'top';

    // --- velocidad (abajo derecha) ---
    const spd = Math.round(p.speedKmh());
    g.textAlign = 'right';
    g.font = `900 ${big}px Rajdhani, sans-serif`;
    g.fillStyle = '#f3f3f3';
    g.fillText(String(spd), W - pad - 60, H - pad - big - 6);
    g.font = `700 ${small}px Rajdhani, sans-serif`;
    g.fillStyle = '#8a8f98';
    g.fillText('KM/H', W - pad, H - pad - big + 4);

    // daño
    const dmgW = Math.min(150, W * 0.16);
    g.fillStyle = 'rgba(255,255,255,0.12)';
    g.fillRect(W - pad - dmgW, H - pad - small * 0.5 - 6, dmgW, 5);
    g.fillStyle = p.damage > 60 ? '#ff4d4d' : p.damage > 30 ? '#ffd23e' : '#d2ff00';
    g.fillRect(W - pad - dmgW, H - pad - small * 0.5 - 6, dmgW * (1 - p.damage / 100), 5);
    g.textAlign = 'left';
    g.fillStyle = '#8a8f98';
    g.font = `600 ${small * 0.85}px Rajdhani, sans-serif`;
    g.fillText('DAÑO ' + Math.round(p.damage) + '%', W - pad - dmgW, H - pad - small * 1.6 - 8);

    // rebufo
    if (p.slipstream) {
      g.textAlign = 'center';
      g.fillStyle = '#d2ff00';
      g.font = `800 ${med}px Rajdhani, sans-serif`;
      g.fillText('◄ REBUFO ►', W / 2, H - pad - med * 2.4);
    }

    // --- posición y vuelta (arriba izquierda) ---
    g.textAlign = 'left';
    if (!isTT) {
      g.font = `900 ${big * 0.9}px Rajdhani, sans-serif`;
      g.fillStyle = '#3834ff';
      g.fillText(`P${race.playerPos}`, pad, pad);
      g.font = `700 ${med}px Rajdhani, sans-serif`;
      g.fillStyle = '#f3f3f3';
      g.fillText(`/${race.cars.length}`, pad + big * 0.9 * 1.15, pad + big * 0.28);
    } else {
      g.font = `900 ${big * 0.7}px Rajdhani, sans-serif`;
      g.fillStyle = '#3834ff';
      g.fillText('CONTRARRELOJ', pad, pad + big * 0.2);
    }
    g.font = `700 ${med}px Rajdhani, sans-serif`;
    g.fillStyle = '#d2ff00';
    g.fillText(`VUELTA ${Math.min(p.lap + 1, race.cfg.laps)}/${race.cfg.laps}`, pad, pad + big * 0.95);

    // tiempos
    g.font = `600 ${small}px Rajdhani, sans-serif`;
    g.fillStyle = '#8a8f98';
    g.fillText(`TIEMPO  ${fmtTime(race.raceTime * 1000)}`, pad, pad + big * 0.95 + med * 1.3);
    g.fillText(`ÚLTIMA  ${fmtTime(p.lastLap)}`, pad, pad + big * 0.95 + med * 1.3 + small * 1.3);
    g.fillStyle = '#d2ff00';
    g.fillText(`MEJOR   ${fmtTime(p.bestLap)}`, pad, pad + big * 0.95 + med * 1.3 + small * 2.6);

    // minimapa
    this.drawMinimap(g, W, H, race);

    // mensaje central
    if (race.messageT > 0) {
      g.textAlign = 'center';
      g.font = `900 ${big * 0.75}px Rajdhani, sans-serif`;
      g.fillStyle = `rgba(210,255,0,${Math.min(1, race.messageT)})`;
      g.fillText(race.message, W / 2, H * 0.24);
    }

    // semáforo
    if (race.state === 'countdown') {
      const t = race.countdownT;
      const lights = t > 2.8 ? 0 : t > 1.8 ? 1 : t > 0.8 ? 2 : 3;
      const R = Math.max(12, Math.min(W, H) * 0.032);
      const cx = W / 2 - R * 2.2, cy = H * 0.3;
      for (let i = 0; i < 3; i++) {
        g.beginPath(); g.arc(cx + i * R * 2.2, cy, R * 0.8, 0, 7);
        g.fillStyle = i < lights ? '#ff4d4d' : 'rgba(255,255,255,0.15)';
        g.fill();
      }
      g.textAlign = 'center';
      g.font = `900 ${med}px Rajdhani, sans-serif`;
      g.fillStyle = '#f3f3f3';
      g.fillText(lights >= 3 ? '¡YA!' : 'PREPARADOS...', W / 2, cy + R * 1.4);
    }
    g.textAlign = 'left';
  }

  private drawMinimap(g: CanvasRenderingContext2D, W: number, H: number, race: RaceManager) {
    const size = Math.max(90, Math.min(W, H) * 0.22);
    const pad = Math.max(10, Math.min(W, H) * 0.02);
    const x0 = W - size - pad, y0 = pad;
    const t = race.track;
    const bw = t.bounds.maxX - t.bounds.minX, bh = t.bounds.maxY - t.bounds.minY;
    const sc = (size - 16) / Math.max(bw, bh);
    const ox = x0 + (size - bw * sc) / 2, oy = y0 + (size - bh * sc) / 2;
    g.save();
    g.globalAlpha = 0.85;
    g.fillStyle = 'rgba(5,6,10,0.6)';
    g.beginPath(); (g as any).roundRect(x0, y0, size, size, 10); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.5)';
    g.lineWidth = 2;
    g.beginPath();
    const N = t.samples.length;
    for (let i = 0; i <= N; i += 3) {
      const s = t.samples[i % N];
      const x = ox + (s.x - t.bounds.minX) * sc, y = oy + (s.y - t.bounds.minY) * sc;
      if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
    for (const c of race.cars) {
      const x = ox + (c.x - t.bounds.minX) * sc, y = oy + (c.y - t.bounds.minY) * sc;
      g.fillStyle = c.isPlayer ? '#d2ff00' : '#ff624d';
      g.beginPath(); g.arc(x, y, c.isPlayer ? 4 : 3, 0, 7); g.fill();
    }
    g.restore();
  }
}
