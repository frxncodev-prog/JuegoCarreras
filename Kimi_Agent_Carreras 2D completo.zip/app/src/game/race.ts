// ============================================================
// Controlador de carrera: parrilla, semáforo, vueltas, posiciones
// ============================================================
import { Car, aiDrive, aiName, type CarInput, type Upgrades } from './car';
import { Track } from './track';
import { Particles } from './particles';
import { DIFFICULTIES, trackById, vehicleById, vehiclesByCategory, type DifficultyId, type WeatherOption } from './data';
import type { SaveData } from './save';
import { upOf } from './save';

export type RaceMode = 'quick' | 'championship' | 'timetrial';

export interface RaceConfig {
  trackId: string;
  category: string;
  vehicleId: string;
  laps: number;
  difficulty: DifficultyId;
  weather: WeatherOption;
  mode: RaceMode;
  aiCount: number;
  save: SaveData;
  champGrid?: string[]; // orden de parrilla para campeonato (player último por puntos)
}

export interface RaceEntry {
  name: string; isPlayer: boolean; vehName: string;
  time: number; bestLap: number; lapsDone: number;
}

const AI_COLORS: [string, string][] = [
  ['#ff624d', '#111'], ['#4da3ff', '#eee'], ['#ffd23e', '#222'], ['#c07bff', '#111'],
  ['#00e5c0', '#111'], ['#f3f3f3', '#3834ff'], ['#ff9f43', '#111'], ['#7bed9f', '#123'],
];

export class RaceManager {
  track: Track;
  cfg: RaceConfig;
  cars: Car[] = [];
  player: Car;
  particles = new Particles();
  diff: (typeof DIFFICULTIES)[number] = DIFFICULTIES[0];
  state: 'countdown' | 'racing' | 'finished' = 'countdown';
  countdownT = 3.8;
  raceTime = 0;
  positions: Car[] = [];
  message = '';
  messageT = 0;
  playerPos = 1;
  finalEntries: RaceEntry[] = [];
  onBeep: ((f: number, d?: number) => void) | null = null;
  onThud: ((i: number) => void) | null = null;
  lastBeepStep = -1;

  constructor(cfg: RaceConfig) {
    this.cfg = cfg;
    this.track = new Track(trackById(cfg.trackId));
    this.diff = DIFFICULTIES.find(d => d.id === cfg.difficulty) ?? DIFFICULTIES[1];
    const isTT = cfg.mode === 'timetrial';
    const aiCount = isTT ? 0 : cfg.aiCount;

    // jugador
    const veh = vehicleById(cfg.vehicleId);
    this.player = new Car(veh, upOf(cfg.save, veh.id), true, 'TÚ');
    this.cars.push(this.player);

    // rivales de la misma categoría
    const pool = vehiclesByCategory(cfg.category);
    const used = new Set<string>();
    for (let i = 0; i < aiCount; i++) {
      let v = pool[Math.floor(Math.random() * pool.length)];
      let guard = 0;
      while (used.has(v.id) && guard++ < 10) v = pool[Math.floor(Math.random() * pool.length)];
      used.add(v.id);
      const lvl = Math.min(5, Math.floor(this.diff.aiSpeed * 3 + Math.random() * 2));
      const up: Upgrades = { engine: lvl, brakes: lvl, tires: lvl, aero: lvl };
      const c = new Car(v, up, false, aiName(i), AI_COLORS[i % 8][0], AI_COLORS[i % 8][1]);
      this.cars.push(c);
    }

    // parrilla: jugador último en rápida/contrarreloj; en campeonato según puntos
    const gridOrder = [...this.cars];
    if (cfg.mode === 'quick') {
      // aleatoria, jugador al final
      const ais = gridOrder.filter(c => !c.isPlayer).sort(() => Math.random() - 0.5);
      const ord = cfg.mode === 'quick' ? [...ais, this.player] : gridOrder;
      this.placeOnGrid(ord);
    } else if (cfg.champGrid) {
      const ord: Car[] = [];
      for (const name of cfg.champGrid) {
        const c = this.cars.find(x => x.name === name);
        if (c) ord.push(c);
      }
      for (const c of this.cars) if (!ord.includes(c)) ord.push(c);
      this.placeOnGrid(ord);
    } else this.placeOnGrid(gridOrder);

    for (const c of this.cars) {
      const N = this.track.samples.length;
      c.sampleIdx = this.track.nearest(c.x, c.y);
      c.progress = c.sampleIdx - N; // antes de la línea
      c.lap = 0;
    }
    this.positions = [...this.cars];
  }

  private placeOnGrid(ord: Car[]) {
    ord.forEach((c, i) => {
      const slot = this.track.gridSlots[Math.min(i, this.track.gridSlots.length - 1)];
      c.x = slot.x; c.y = slot.y; c.angle = slot.angle;
    });
  }

  say(msg: string, t = 2.2) { this.message = msg; this.messageT = t; }

  step(dt: number, input: CarInput) {
    const rain = this.cfg.weather.rain;
    if (this.state === 'countdown') {
      this.countdownT -= dt;
      const step = Math.ceil(this.countdownT);
      if (step !== this.lastBeepStep && step >= 0 && step <= 3) {
        this.lastBeepStep = step;
        this.onBeep?.(step === 0 ? 880 : 440, step === 0 ? 0.4 : 0.12);
      }
      if (this.countdownT <= 0) {
        this.state = 'racing';
        this.say('¡YA!', 1.2);
      }
      return; // coches quietos durante el semáforo
    }

    this.raceTime += dt;
    if (this.messageT > 0) this.messageT -= dt;

    const N = this.track.samples.length;
    for (const car of this.cars) {
      if (car.finished) {
        // los coches que acaban siguen rodando con IA suave
        const inp = aiDrive(car, this.track, dt, this.cars, { aiSpeed: 0.8, aiMistakes: 0 }, this.raceTime);
        inp.throttle *= 0.6;
        car.step(dt, inp, this.track, rain, this.cars);
        continue;
      }
      let inp: CarInput;
      if (car.isPlayer) inp = this.cfg.mode === 'timetrial' || true ? input : input;
      else inp = aiDrive(car, this.track, dt, this.cars, this.diff, this.raceTime);

      const prevLapMark = Math.floor(car.progress / N);
      car.step(dt, inp, this.track, rain, this.cars);

      // sonido de impacto
      const hit = (car as any).justHit;
      if (hit) { this.onThud?.(hit); (car as any).justHit = 0;
        for (let i = 0; i < 6; i++) this.particles.emit(2, car.x, car.y, (Math.random() - 0.5) * 14, (Math.random() - 0.5) * 14, 0.5, 2);
      }

      // cruce de línea
      const newMark = Math.floor(car.progress / N);
      if (newMark > prevLapMark) {
        const lapMs = this.raceTime * 1000 - car.lapStart;
        car.lapStart = this.raceTime * 1000;
        if (car.progress > 0) {
          car.lastLap = lapMs;
          if (!car.bestLap || lapMs < car.bestLap) car.bestLap = lapMs;
          car.lap = newMark;
          const totalLaps = this.cfg.laps;
          if (newMark >= totalLaps) {
            car.finished = true;
            car.finishTime = this.raceTime;
            if (car.isPlayer) { this.say('¡BANDERA A CUADROS!', 3); }
          } else if (car.isPlayer) {
            if (newMark === totalLaps - 1) this.say('¡ÚLTIMA VUELTA!', 2.5);
            else this.say(`VUELTA ${newMark + 1}/${totalLaps}`, 1.6);
          }
        }
      }

      // partículas de conducción
      const spd = car.speed();
      if (car.drifting && spd > 8 && Math.random() < dt * 30) {
        const bx = car.x - Math.cos(car.angle) * 2, by = car.y - Math.sin(car.angle) * 2;
        this.particles.emit(car.offTrack ? 1 : 0, bx, by, -car.vx * 0.15, -car.vy * 0.15, 0.7, 2.2);
      }
      if (car.offTrack && spd > 10 && Math.random() < dt * 20) {
        this.particles.emit(1, car.x, car.y, -car.vx * 0.1, -car.vy * 0.1, 0.8, 2.6);
      }
      if (rain > 0 && spd > 15 && Math.random() < dt * 22) {
        const bx = car.x - Math.cos(car.angle) * 2.5, by = car.y - Math.sin(car.angle) * 2.5;
        this.particles.emit(3, bx, by, -car.vx * 0.1, -car.vy * 0.1, 0.5, 2.4);
      }
    }

    this.particles.update(dt);

    // posiciones
    this.positions = [...this.cars].sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1;
      if (b.finished) return 1;
      return b.progress - a.progress;
    });
    this.playerPos = this.positions.indexOf(this.player) + 1;

    // fin de carrera del jugador
    if (this.player.finished && this.state === 'racing') {
      this.state = 'finished';
      this.buildResults();
    }
  }

  private buildResults() {
    this.finalEntries = this.positions.map((c) => ({
      name: c.name, isPlayer: c.isPlayer, vehName: c.veh.name,
      time: c.finished ? c.finishTime * 1000 : 0,
      bestLap: c.bestLap, lapsDone: c.lap,
    }));
  }

  // premios según resultado
  rewards(): { money: number; xp: number } {
    const pos = this.playerPos;
    const tier = { kart: 1, touring: 1.6, gt3: 2.4, super: 3.2, f2: 4, f1: 6 }[this.cfg.category as string] ?? 1;
    const diffMul = this.cfg.difficulty === 'hard' ? 1.5 : this.cfg.difficulty === 'medium' ? 1.2 : 1;
    const posMoney = [5000, 3800, 3000, 2400, 1900, 1500, 1200, 900, 700, 500][pos - 1] ?? 400;
    const money = Math.round(posMoney * tier * diffMul * (this.cfg.mode === 'timetrial' ? 0.5 : 1));
    const xp = Math.round((this.cfg.mode === 'timetrial' ? 200 : 520 - pos * 45) * tier * diffMul + this.player.bestLap * 0);
    return { money: Math.max(200, money), xp: Math.max(80, xp) };
  }
}
