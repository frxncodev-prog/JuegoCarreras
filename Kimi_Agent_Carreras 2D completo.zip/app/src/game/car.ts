// ============================================================
// Física arcade de conducción + IA de rivales
// ============================================================
import type { Vehicle } from './data';
import type { Track } from './track';

export interface CarInput { throttle: number; brake: number; steer: number; handbrake: boolean }

export interface Upgrades { engine: number; brakes: number; tires: number; aero: number }

export class Car {
  veh: Vehicle;
  up: Upgrades;
  isPlayer: boolean;
  name: string;
  color: string;
  color2: string;

  x = 0; y = 0; angle = 0;
  vx = 0; vy = 0;
  steerVis = 0;
  damage = 0;             // 0..100
  sampleIdx = 0;          // índice en la pista
  progress = 0;           // progreso continuo (muestras)
  lap = 0;
  lapStart = 0;
  lastLap = 0;
  bestLap = 0;
  finished = false;
  finishTime = 0;
  offTrack = false;
  drifting = false;
  slipstream = false;
  // IA
  aiOffset = 0;           // offset lateral preferido
  aiTargetOffset = 0;
  aiSkill: number;        // 0.85..1.02
  aggression: number;
  stuckTimer = 0;
  prevSpeed = 0;

  constructor(veh: Vehicle, up: Upgrades, isPlayer: boolean, name: string, color?: string, color2?: string) {
    this.veh = veh; this.up = up; this.isPlayer = isPlayer; this.name = name;
    this.color = color ?? veh.colors[0];
    this.color2 = color2 ?? veh.colors[1];
    this.aiSkill = 0.9 + Math.random() * 0.12;
    this.aggression = 0.4 + Math.random() * 0.6;
  }

  // Estadísticas efectivas con mejoras y daño
  eff() {
    const s = this.veh.stats;
    const dmgF = 1 - this.damage * 0.0035;
    return {
      topSpeed: s.topSpeed * (1 + this.up.engine * 0.025) * dmgF / 3.6, // m/s
      accel: s.accel * (1 + this.up.engine * 0.05) * (1 - this.damage * 0.004),
      grip: s.grip * (1 + this.up.tires * 0.045),
      brake: s.brake * (1 + this.up.brakes * 0.07),
      aero: 1 + this.up.aero * 0.08,
      weight: s.weight,
    };
  }

  speed(): number { return Math.hypot(this.vx, this.vy); }
  speedKmh(): number { return this.speed() * 3.6; }
  forwardSpeed(): number { return this.vx * Math.cos(this.angle) + this.vy * Math.sin(this.angle); }

  step(dt: number, input: CarInput, track: Track, rain: number, world: Car[]) {
    const e = this.eff();
    const dirX = Math.cos(this.angle), dirY = Math.sin(this.angle);
    let vF = this.vx * dirX + this.vy * dirY;
    let vL = -this.vx * dirY + this.vy * dirX;

    // superficie
    this.offTrack = !track.onAsphalt(this.x, this.y, this.sampleIdx, 0.6);
    let surfGrip = this.offTrack ? 0.5 : 1;
    if (rain > 0) surfGrip *= (this.offTrack ? 0.85 : 0.78) * (1 + this.up.tires * 0.02);
    const surfDrag = this.offTrack ? 2.2 : 1;

    // --- motor ---
    const slipBoost = this.slipstream ? 1.12 : 1;
    const topMs = e.topSpeed * slipBoost;
    if (input.throttle > 0 && vF < topMs) {
      const forceCurve = Math.max(0.15, 1 - (vF / topMs) * 0.75);
      vF += input.throttle * e.accel * forceCurve * dt * (this.offTrack ? 0.6 : 1);
    }
    // --- freno ---
    if (input.brake > 0) {
      if (vF > 0.5) vF -= e.brake * input.brake * dt;
      else vF = Math.max(vF - 4 * input.brake * dt, -12); // marcha atrás
    }
    // freno de mano
    const hb = input.handbrake && Math.abs(vF) > 4;
    if (hb) vF -= Math.sign(vF) * 8 * dt;

    // resistencias
    vF -= vF * (0.02 * surfDrag) * dt;
    vF -= Math.sign(vF) * 0.25 * surfDrag * dt;
    const dragK = 0.00012 * surfDrag / e.aero;
    vF -= dragK * vF * Math.abs(vF) * dt * 60;

    // --- dirección ---
    const spd = Math.abs(vF);
    const steerRange = 1.15 * (1 / (1 + spd * 0.055)); // menos giro a alta velocidad
    const steer = input.steer * steerRange * Math.sign(vF || 1);
    const latGMax = e.grip * 9.8 * surfGrip * (hb ? 0.45 : 1) * e.aero;
    // velocidad angular por geometría de giro, limitada por agarre
    let omega = 0;
    if (spd > 0.3) {
      const turnRadius = 4.2 / Math.tan(Math.max(-1, Math.min(1, steer)) * 0.55 + 1e-5);
      omega = spd / Math.max(3.5, Math.abs(turnRadius)) * Math.sign(steer || 1e-5) * Math.sign(turnRadius);
      // límite físico por agarre lateral
      const maxOmega = latGMax / Math.max(spd, 1);
      if (Math.abs(omega) > maxOmega) {
        omega = Math.sign(omega) * maxOmega;
        // subviraje: el exceso se convierte en deslizamiento
        vL += Math.sign(omega) * (Math.abs(omega) - 0) * 0; // (implícito en vL)
      }
    }
    if (hb) omega *= 1.7; // el freno de mano rota el coche
    this.angle += omega * dt * Math.sign(vF >= 0 ? 1 : -1);

    // --- grip lateral (derrapes) ---
    const gripRate = (hb ? 1.6 : 5.2 * e.grip) * surfGrip;
    const gripF = Math.exp(-gripRate * dt);
    vL *= gripF;
    this.drifting = Math.abs(vL) > 3.2 || (hb && spd > 6);
    if (this.drifting) vL *= Math.exp(-1.2 * dt); // disipación extra al derrapar

    // recomponer velocidad en el nuevo marco
    const ndx = Math.cos(this.angle), ndy = Math.sin(this.angle);
    this.vx = ndx * vF - ndy * vL;
    this.vy = ndy * vF + ndx * vL;
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    this.steerVis += ((hb ? input.steer * 1.4 : input.steer) - this.steerVis) * Math.min(1, dt * 10);

    // --- progreso en pista ---
    const prev = this.sampleIdx;
    this.sampleIdx = track.nearest(this.x, this.y, prev);
    let di = this.sampleIdx - prev;
    const N = track.samples.length;
    if (di > N / 2) di -= N;
    if (di < -N / 2) di += N;
    this.progress += di;

    // colisiones coche-coche
    for (const o of world) {
      if (o === this) continue;
      const dx = o.x - this.x, dy = o.y - this.y;
      const d = Math.hypot(dx, dy);
      const minD = 4.4;
      if (d < minD && d > 0.001) {
        const nx = dx / d, ny = dy / d;
        const overlap = (minD - d) / 2;
        this.x -= nx * overlap; this.y -= ny * overlap;
        o.x += nx * overlap; o.y += ny * overlap;
        // intercambio de momento simplificado
        const relVx = o.vx - this.vx, relVy = o.vy - this.vy;
        const relN = relVx * nx + relVy * ny;
        if (relN < 0) {
          const mA = e.weight, mB = o.eff().weight;
          const imp = (-relN * 1.6) / (1 / mA + 1 / mB);
          this.vx -= (imp / mA) * nx; this.vy -= (imp / mA) * ny;
          o.vx += (imp / mB) * nx; o.vy += (imp / mB) * ny;
          const hit = Math.abs(relN);
          if (hit > 3) {
            const dmg = hit * 1.6;
            this.damage = Math.min(100, this.damage + dmg);
            o.damage = Math.min(100, o.damage + dmg);
            (this as any).justHit = hit; (o as any).justHit = hit * 0.7;
          }
        }
      }
    }

    // rebufo: coche delante a 8-35 m en un cono
    this.slipstream = false;
    if (spd > 18) {
      for (const o of world) {
        if (o === this) continue;
        const dx = o.x - this.x, dy = o.y - this.y;
        const along = dx * ndx + dy * ndy;
        const side = Math.abs(-dx * ndy + dy * ndx);
        if (along > 7 && along < 38 && side < 3.4) { this.slipstream = true; break; }
      }
    }
    this.prevSpeed = spd;
  }
}

// ============================================================
// IA
// ============================================================
const AI_NAMES = ['Vidal', 'Kessler', 'Onofre', 'Sato', 'Marchetti', 'Ivanov', 'Duarte', 'Lindqvist', 'Okafor', 'Rivas', 'Novak', 'Ferrand', 'Alarcón', 'Brandt', 'Kubo', 'Mäkinen'];
export const aiName = (i: number) => AI_NAMES[i % AI_NAMES.length];

export function aiDrive(car: Car, track: Track, dt: number, world: Car[], difficulty: { aiSpeed: number; aiMistakes: number }, raceTime: number): CarInput {
  const e = car.eff();
  const spd = car.speed();
  const idx = car.sampleIdx;

  // bloqueo: coche más lento delante → cambiar offset lateral para adelantar
  let blocked = false;
  const dirX = Math.cos(car.angle), dirY = Math.sin(car.angle);
  for (const o of world) {
    if (o === car) continue;
    const dx = o.x - car.x, dy = o.y - car.y;
    const along = dx * dirX + dy * dirY;
    const side = -dx * dirY + dy * dirX;
    if (along > 3 && along < 22 && Math.abs(side) < 4) {
      blocked = true;
      if (Math.abs(car.aiTargetOffset - car.aiOffset) < 0.5) {
        // elegir lado con más espacio
        const lat = track.lateral(car.x, car.y, idx);
        const roomL = track.def.width / 2 - lat;
        const roomR = track.def.width / 2 + lat;
        car.aiTargetOffset = (side > 0 ? -1 : 1) * (roomL > roomR ? 1 : -1) * track.def.width * 0.3 * car.aggression;
      }
      break;
    }
  }
  if (!blocked && Math.random() < dt * 0.15) car.aiTargetOffset = (Math.random() - 0.5) * track.def.width * 0.4;
  car.aiTargetOffset = Math.max(-track.def.width * 0.38, Math.min(track.def.width * 0.38, car.aiTargetOffset));
  car.aiOffset += (car.aiTargetOffset - car.aiOffset) * Math.min(1, dt * 1.5);

  // punto objetivo
  const look = 10 + spd * 0.55;
  const tgt = track.lookahead(idx, look, car.aiOffset);
  const dxT = tgt.x - car.x, dyT = tgt.y - car.y;
  let da = Math.atan2(dyT, dxT) - car.angle;
  while (da > Math.PI) da -= 2 * Math.PI;
  while (da < -Math.PI) da += 2 * Math.PI;
  const steer = Math.max(-1, Math.min(1, da * 2.2));

  // velocidad objetivo según curvatura próxima
  const curve = track.maxCurveAhead(idx, 15 + spd * spd * 0.09);
  const latG = e.grip * 9.8 * (car.offTrack ? 0.5 : 1) * difficulty.aiSpeed;
  let vTarget = curve > 0.0008 ? Math.sqrt(latG / curve) * car.aiSkill : 999;
  vTarget = Math.min(vTarget, e.topSpeed * 0.999);
  // errores humanos
  if (Math.random() < difficulty.aiMistakes * dt * 2) vTarget *= 0.85 + Math.random() * 0.1;

  const vErr = vTarget - spd;
  const throttle = vErr > 0 ? Math.min(1, vErr / 6) : 0;
  const brake = vErr < -1 ? Math.min(1, -vErr / 8) : 0;

  // anti-atasco (si choca y queda parado)
  if (spd < 2 && raceTime > 4) car.stuckTimer += dt; else car.stuckTimer = 0;
  if (car.stuckTimer > 1.5) return { throttle: 0.4, brake: 0, steer: -steer, handbrake: false };

  return { throttle, brake, steer, handbrake: false };
}
