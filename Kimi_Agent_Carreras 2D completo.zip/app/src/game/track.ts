// ============================================================
// Geometría y pre-renderizado de circuitos
// ============================================================
import type { TrackDef } from './data';

export interface TrackSample {
  x: number; y: number;       // centro de pista
  nx: number; ny: number;     // normal (izquierda)
  angle: number;              // dirección de la pista
  dist: number;               // distancia acumulada
  curve: number;              // curvatura (1/m)
}

export class Track {
  def: TrackDef;
  samples: TrackSample[] = [];
  length = 0;
  bounds = { minX: 0, minY: 0, maxX: 0, maxY: 0 };
  off: HTMLCanvasElement | null = null; // pista pre-renderizada
  offScale = 1;
  gridSlots: { x: number; y: number; angle: number }[] = [];
  scenery: { x: number; y: number; r: number; kind: number }[] = [];

  constructor(def: TrackDef) {
    this.def = def;
    this.build();
  }

  // Catmull-Rom cerrado
  private build() {
    const cp = this.def.points;
    const n = cp.length;
    const PER = 42;
    const pts: { x: number; y: number }[] = [];
    for (let i = 0; i < n; i++) {
      const p0 = cp[(i - 1 + n) % n], p1 = cp[i], p2 = cp[(i + 1) % n], p3 = cp[(i + 2) % n];
      for (let j = 0; j < PER; j++) {
        const t = j / PER, t2 = t * t, t3 = t2 * t;
        pts.push({
          x: 0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          y: 0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
        });
      }
    }
    // Suavizado ligero
    const sm = pts.map((p, i) => {
      const a = pts[(i - 1 + pts.length) % pts.length], b = pts[(i + 1) % pts.length];
      return { x: p.x * 0.6 + (a.x + b.x) * 0.2, y: p.y * 0.6 + (a.y + b.y) * 0.2 };
    });
    let dist = 0;
    const N = sm.length;
    for (let i = 0; i < N; i++) {
      const p = sm[i], next = sm[(i + 1) % N], prev = sm[(i - 1 + N) % N];
      if (i > 0) dist += Math.hypot(p.x - sm[i - 1].x, p.y - sm[i - 1].y);
      const dx = next.x - prev.x, dy = next.y - prev.y;
      const len = Math.hypot(dx, dy) || 1;
      const angle = Math.atan2(dy, dx);
      // curvatura por cambio de ángulo
      const a0 = Math.atan2(p.y - prev.y, p.x - prev.x);
      const a1 = Math.atan2(next.y - p.y, next.x - p.x);
      let da = a1 - a0;
      while (da > Math.PI) da -= 2 * Math.PI;
      while (da < -Math.PI) da += 2 * Math.PI;
      const segLen = (Math.hypot(p.x - prev.x, p.y - prev.y) + Math.hypot(next.x - p.x, next.y - p.y)) / 2 || 1;
      this.samples.push({
        x: p.x, y: p.y, nx: -dy / len, ny: dx / len, angle, dist,
        curve: da / segLen,
      });
    }
    this.length = dist + Math.hypot(sm[0].x - sm[N - 1].x, sm[0].y - sm[N - 1].y);
    // bounds
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    const pad = this.def.width / 2 + 60;
    for (const s of this.samples) {
      minX = Math.min(minX, s.x); maxX = Math.max(maxX, s.x);
      minY = Math.min(minY, s.y); maxY = Math.max(maxY, s.y);
    }
    this.bounds = { minX: minX - pad, minY: minY - pad, maxX: maxX + pad, maxY: maxY + pad };
    // parrilla: detrás de la línea de meta (sample 0), intercalando lados
    this.gridSlots = [];
    const w = this.def.width;
    for (let i = 0; i < 10; i++) {
      const idx = ((N - 12 - Math.floor(i / 2) * 8) % N + N) % N;
      const s = this.samples[idx];
      const side = i % 2 === 0 ? 1 : -1;
      this.gridSlots.push({ x: s.x + s.nx * side * w * 0.22, y: s.y + s.ny * side * w * 0.22, angle: s.angle });
    }
    // decoración (árboles/rocas) en la hierba
    let seed = 7;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 130; i++) {
      const s = this.samples[Math.floor(rnd() * N)];
      const side = rnd() > 0.5 ? 1 : -1;
      const d = w / 2 + 8 + rnd() * 40;
      this.scenery.push({ x: s.x + s.nx * side * d + (rnd() - 0.5) * 20, y: s.y + s.ny * side * d + (rnd() - 0.5) * 20, r: 3 + rnd() * 6, kind: Math.floor(rnd() * 3) });
    }
  }

  // Busca la muestra más cercana a (x,y) partiendo de una pista (índice previo)
  nearest(x: number, y: number, hint = -1): number {
    const N = this.samples.length;
    let best = 0, bd = Infinity;
    if (hint >= 0) {
      for (let o = -40; o <= 40; o++) {
        const i = ((hint + o) % N + N) % N;
        const s = this.samples[i];
        const d = (s.x - x) * (s.x - x) + (s.y - y) * (s.y - y);
        if (d < bd) { bd = d; best = i; }
      }
      return best;
    }
    for (let i = 0; i < N; i += 4) {
      const s = this.samples[i];
      const d = (s.x - x) * (s.x - x) + (s.y - y) * (s.y - y);
      if (d < bd) { bd = d; best = i; }
    }
    for (let o = -4; o <= 4; o++) {
      const i = ((best + o) % N + N) % N;
      const s = this.samples[i];
      const d = (s.x - x) * (s.x - x) + (s.y - y) * (s.y - y);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  // Distancia lateral con signo al centro de pista
  lateral(x: number, y: number, idx: number): number {
    const s = this.samples[idx];
    return (x - s.x) * s.nx + (y - s.y) * s.ny;
  }

  onAsphalt(x: number, y: number, idx: number, margin = 0): boolean {
    return Math.abs(this.lateral(x, y, idx)) <= this.def.width / 2 + margin;
  }

  // Punto en la línea de carrera a una distancia por delante (para IA)
  lookahead(idx: number, distAhead: number, lateralOff: number): { x: number; y: number; curve: number } {
    const N = this.samples.length;
    const s0 = this.samples[idx];
    const targetDist = s0.dist + distAhead;
    let i = idx;
    for (let k = 0; k < N; k++) {
      const j = (idx + k) % N;
      if (this.samples[j].dist >= targetDist || (k > N / 2)) { i = j; break; }
      i = j;
    }
    const s = this.samples[i];
    // desplazamiento de línea de carrera: cortar hacia el interior de la curva
    const cut = Math.max(-1, Math.min(1, -s.curve * 90)) * this.def.width * 0.28;
    const off = lateralOff + cut;
    return { x: s.x + s.nx * off, y: s.y + s.ny * off, curve: s.curve };
  }

  maxCurveAhead(idx: number, distAhead: number): number {
    const N = this.samples.length;
    const s0 = this.samples[idx];
    let mc = 0;
    for (let k = 0; k < N; k++) {
      const j = (idx + k) % N;
      if (this.samples[j].dist > s0.dist + distAhead && k > 4) break;
      mc = Math.max(mc, Math.abs(this.samples[j].curve));
      if (k > N * 0.6) break;
    }
    return mc;
  }

  // ============ PRE-RENDER ============
  prerender(theme: { grass: string; grass2: string; asphalt: string; curbA: string; curbB: string }, night: number): HTMLCanvasElement {
    const scale = 1.4; // px por metro en el buffer
    this.offScale = scale;
    const w = Math.ceil((this.bounds.maxX - this.bounds.minX) * scale);
    const h = Math.ceil((this.bounds.maxY - this.bounds.minY) * scale);
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d')!;
    const tx = (x: number) => (x - this.bounds.minX) * scale;
    const ty = (y: number) => (y - this.bounds.minY) * scale;
    // hierba / fondo
    g.fillStyle = theme.grass;
    g.fillRect(0, 0, w, h);
    // manchas de hierba
    g.fillStyle = theme.grass2;
    let seed = 3;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 240; i++) {
      g.globalAlpha = 0.25 + rnd() * 0.3;
      g.beginPath();
      g.ellipse(rnd() * w, rnd() * h, 20 + rnd() * 80, 14 + rnd() * 60, rnd() * 3, 0, 7);
      g.fill();
    }
    g.globalAlpha = 1;
    const path = (offset: number, widthM: number) => {
      g.beginPath();
      const N = this.samples.length;
      for (let i = 0; i <= N; i++) {
        const s = this.samples[i % N];
        const x = tx(s.x + s.nx * offset), y = ty(s.y + s.ny * offset);
        if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
      }
      g.lineWidth = widthM * scale;
      g.lineJoin = 'round'; g.lineCap = 'round';
    };
    // zona de seguridad (asfalto gastado alrededor)
    g.strokeStyle = 'rgba(0,0,0,0.18)';
    path(0, this.def.width + 7); g.stroke();
    // asfalto principal
    g.strokeStyle = theme.asphalt;
    path(0, this.def.width); g.stroke();
    // textura del asfalto
    g.strokeStyle = 'rgba(255,255,255,0.04)';
    path(0, this.def.width * 0.55); g.stroke();
    // piano (curbs)
    const hw = this.def.width / 2;
    g.lineWidth = 1.6 * scale;
    const N = this.samples.length;
    for (let side = -1; side <= 1; side += 2) {
      for (let i = 0; i < N; i += 2) {
        const s = this.samples[i];
        const curb = Math.abs(s.curve) > 0.004;
        g.strokeStyle = (i / 2) % 2 === 0 ? theme.curbA : theme.curbB;
        g.globalAlpha = curb ? 1 : 0.55;
        g.beginPath();
        g.moveTo(tx(s.x + s.nx * side * (hw - 0.8)), ty(s.y + s.ny * side * (hw - 0.8)));
        const s2 = this.samples[(i + 2) % N];
        g.lineTo(tx(s2.x + s2.nx * side * (hw - 0.8)), ty(s2.y + s2.ny * side * (hw - 0.8)));
        g.stroke();
      }
    }
    g.globalAlpha = 1;
    // línea de salida (cuadros)
    const s0 = this.samples[0];
    g.save();
    g.translate(tx(s0.x), ty(s0.y));
    g.rotate(s0.angle);
    const sq = (this.def.width / 8) * scale;
    for (let r = 0; r < 2; r++)
      for (let i = 0; i < 8; i++) {
        g.fillStyle = (r + i) % 2 === 0 ? '#f3f3f3' : '#111';
        g.fillRect(r * sq - sq, -this.def.width / 2 * scale + i * sq, sq, sq);
      }
    g.restore();
    // decoración
    for (const sc of this.scenery) {
      if (sc.kind === 0) {
        g.fillStyle = night > 0.5 ? '#0c1f14' : '#1d4a2a';
        g.beginPath(); g.arc(tx(sc.x), ty(sc.y), sc.r * scale, 0, 7); g.fill();
        g.fillStyle = 'rgba(0,0,0,0.3)';
        g.beginPath(); g.arc(tx(sc.x + 1.5), ty(sc.y + 1.5), sc.r * scale * 0.8, 0, 7); g.fill();
      } else if (sc.kind === 1) {
        g.fillStyle = night > 0.5 ? '#1a1a1e' : '#4a4a52';
        g.beginPath(); g.arc(tx(sc.x), ty(sc.y), sc.r * scale * 0.6, 0, 7); g.fill();
      } else {
        g.fillStyle = 'rgba(0,0,0,0.25)';
        g.fillRect(tx(sc.x) - sc.r * scale, ty(sc.y) - sc.r * scale * 0.4, sc.r * scale * 2, sc.r * scale * 0.8);
      }
    }
    this.off = c;
    return c;
  }
}
