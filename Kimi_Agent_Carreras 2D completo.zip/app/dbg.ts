import { RaceManager } from './src/game/race';
import { WEATHERS } from './src/game/data';
import { defaultSave } from './src/game/save';

const race = new RaceManager({ trackId: 'costa', category: 'kart', vehicleId: 'kart1', laps: 2,
  difficulty: 'medium', weather: WEATHERS[0], mode: 'quick', aiCount: 7, save: defaultSave() } as any);
const t = race.track;
console.log('N samples:', t.samples.length, 'length:', t.length.toFixed(0), 'width:', t.def.width);
console.log('grid[0..3]:', t.gridSlots.slice(0,4).map(s=>`(${s.x.toFixed(0)},${s.y.toFixed(0)})`).join(' '));
for (const c of race.cars) {
  const idx = t.nearest(c.x, c.y);
  console.log(`${c.name} pos=(${c.x.toFixed(1)},${c.y.toFixed(1)}) angle=${c.angle.toFixed(2)} nearest=${idx} lat=${t.lateral(c.x,c.y,idx).toFixed(1)} prog=${c.progress}`);
}
const s0 = t.samples[0];
console.log('sample0:', s0.x.toFixed(0), s0.y.toFixed(0), 'angle', s0.angle.toFixed(2));
// max curvature
let mc=0; for (const s of t.samples) mc=Math.max(mc,Math.abs(s.curve));
console.log('maxCurve:', mc.toFixed(4), '-> vmax kart:', Math.sqrt(1.25*9.8/mc).toFixed(1), 'm/s =', (Math.sqrt(1.25*9.8/mc)*3.6).toFixed(0), 'km/h');
