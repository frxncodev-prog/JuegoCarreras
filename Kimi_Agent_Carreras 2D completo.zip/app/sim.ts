import { RaceManager } from './src/game/race';
import { WEATHERS } from './src/game/data';
import { defaultSave } from './src/game/save';

const cfg: any = {
  trackId: 'costa', category: 'kart', vehicleId: 'kart1', laps: 2,
  difficulty: 'medium', weather: WEATHERS[0], mode: 'quick', aiCount: 7, save: defaultSave(),
};
const race = new RaceManager(cfg);
// saltar semáforo
for (let i = 0; i < 300; i++) race.step(1 / 60, { throttle: 0, brake: 0, steer: 0, handbrake: false });

const inp = { throttle: 1, brake: 0, steer: 0, handbrake: false };
for (let s = 0; s < 180; s++) {
  for (let i = 0; i < 60; i++) race.step(1 / 60, inp);
  const info = race.cars.map(c => `${c.name}${c.isPlayer ? '*' : ''}:prog=${c.progress.toFixed(0)} off=${c.offTrack ? 1 : 0} spd=${c.speedKmh().toFixed(0)} dmg=${c.damage.toFixed(0)}`).join(' | ');
  if (s % 15 === 0 || s === 179) console.log(`t=${s}s`, info);
}
console.log('POSICIONES:', race.positions.map(c => c.name + (c.isPlayer ? '*' : '') + ' lap' + c.lap).join(', '));
console.log('laps AI:', race.cars.filter(c=>!c.isPlayer).map(c=>c.lap).join(','));
